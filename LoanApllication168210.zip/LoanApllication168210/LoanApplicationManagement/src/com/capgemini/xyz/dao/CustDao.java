package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;








import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.exception.CustomerException;
import com.capgemini.xyz.util.DBConnecton;

public class CustDao implements ICustDao {
	private Logger logger = Logger.getLogger(CustDao.class);
	Connection conn;
	long ret;
	public CustDao() {
		PropertyConfigurator.configure("./resources/log4j.properties");
	}

	PreparedStatement insertStmt = null;

	
	/*******************************************************************************************************
	 - Function Name	:	insertCustomer(CustomerBean bean)
	 - Input Parameters	:	CustomerBean bean
	 - Return Type		:	long
	 - Throws			:  CustomerException
	 - Author			:	aditya
	 - Creation Date	:	16/02/2019
	 - Description		:	Adding Customer
	 ********************************************************************************************************/
	

	@Override
	public long inserCust(CustomerBean bean) {
		logger.info("Customer registration started");
		
		try {

			conn = DBConnecton.getConnection();
			Statement stmt=conn.createStatement();
			
			
			String sql=("insert into customer(cust_Id ,cust_name, address ,email,mobileNo ) values (cust_seq.nextval,?,?,?,?) ");
			insertStmt=conn.prepareStatement(sql);
			insertStmt.setString(1, bean.getCustomername());
			insertStmt.setString(2, bean.getAddress());
			insertStmt.setString(3, bean.getEmail());
			insertStmt.setString(4, bean.getMobileNo());
			int i=insertStmt.executeUpdate();
			
 System.out.println("customer information saved successfully");
 logger.info("customer details added succesfully");
 

		
		
	 String q=("select cust_id from customer where cust_name=?");
insertStmt =conn.prepareStatement(q);
	 insertStmt.setString(1, bean.getCustomername());
	ResultSet resultSet=insertStmt.executeQuery();
	 while(resultSet.next()){
        ret =resultSet.getInt(1);
        System.out.println("your customerId is:"+ret);
     
 }

	if(i!=1){
		System.out.println("insertion not done properly");
	}
	
	}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return ret;
}
}