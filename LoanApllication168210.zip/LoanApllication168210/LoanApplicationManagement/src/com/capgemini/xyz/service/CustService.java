package com.capgemini.xyz.service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.dao.CustDao;
import com.capgemini.xyz.dao.ICustDao;
import com.capgemini.xyz.exception.CustomerException;

public class CustService implements ICustService {
	ICustDao icustdao=new CustDao();
	/*******************************************************************************************************
	 - Function Name	:	validatePhoneNumber
	 - Input Parameters	:	String 
	 - Return Type		:	boolean
	 - Throws			:  CustomerException
	 - Author			:	Aditya
	 - Creation Date	:	16/02/2019
	 - Description		:	validating mobile number
	 ********************************************************************************************************/
	

	@Override
	public boolean validatePhoneNumber(String mobileNo) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, mobileNo)) {
			return true;
		} else {

			return false;
		}

	}
	/*******************************************************************************************************
	 - Function Name	:	validateCustomerName
	 - Input Parameters	:	String 
	 - Return Type		:	boolean
	 - Throws			:  CustomerException
	 - Author			:	Aditya
	 - Creation Date	:	16/02/2019
	 - Description		:	validating customer name
	 ********************************************************************************************************/
	

	@Override
	public boolean validateCustomerName(String customername) {
		String patterns = "[A-Za-z ]{1,20}";
		if (Pattern.matches(patterns, customername)) {
			return true;
		} else {
			return false;
		}
	}

	/*******************************************************************************************************
	 - Function Name	:	validateMailId
	 - Input Parameters	:	String 
	 - Return Type		:	boolean
	 - Throws			:  CustomerException
	 - Author			:	Aditya
	 - Creation Date	:	16/02/2019
	 - Description		:	validating email
	 ********************************************************************************************************/
	@Override
	public boolean validateMailId(String email) {
		String patterns = "[A-Za-z0-9]{1,}[@][A-Za-z0-9.]{1,}";
		if (Pattern.matches(patterns, email)) {
			return true;
		} else {
			return false;
		}
	}
	/*******************************************************************************************************
	 - Function Name	:	insertCustomer(CustomerBean bean)
	 - Input Parameters	:	CustomerBean bean
	 - Return Type		:	long
	 - Throws			:  CustomerException
	 - Author			:	aditya
	 - Creation Date	:	16//02/2019
	 - Description		:	adding customer to database calls dao method inserCustomer(CustomerBean bean) 
	 ********************************************************************************************************/
	
	@Override
	public long inserCustomer(CustomerBean bean) throws CustomerException{
		long ret=icustdao.inserCust(bean);
		return ret;
	}


	
	
	
}
