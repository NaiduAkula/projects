package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.exception.CustomerException;
import com.capgemini.xyz.service.CustService;
import com.capgemini.xyz.service.ICustService;



public class ExecuterMain {
	 static int choice;
	 static ICustService icustservice=new CustService();
	 static Scanner scanner= new Scanner(System.in);
	public static void main(String[] args) throws CustomerException {
	
	while (true) {
		System.out.println();
		System.out.println();
		System.out.println("   welcome To Finance Company ");
		System.out.println("_______________________________\n");

		System.out.println(" \nXYZ Finance Welcomes You \n");
		System.out.println(" 1.Register Customer\n");
	
		System.out.println(" 2.Exit\n");
		
		System.out.println("________________________________");
		choice= scanner.nextInt();
		switch (choice) {
		case 1:
			getInputs();
			break;
			
		case 2:
			System.out.println("Exit");
	    	System.exit(0);
			break;
			

}
}
	}
	private static void getInputs() throws CustomerException {

	 int customerId;
 String customername;
		
	 String address;
	String email;
	String mobileNo;
	while (true) {
		scanner.nextLine();
		System.out.println("Enter customer name");

		customername = scanner.nextLine();
		

		if (icustservice.validateCustomerName(customername)) {
			break;
		} else {
			System.out.println("Invalid customername");
		}
	}

	while (true) {
		System.out.println("Enter phone number");

		mobileNo = scanner.next();

		if (icustservice.validatePhoneNumber(mobileNo)) {
			break;
		} else {
			System.out.println("Invalid phone number");
		}
	}

	while (true) {
		System.out.println("Please enter mail id ");

		email = scanner.next();

		if (icustservice.validateMailId(email)) {
			break;
		} else {
			System.out.println("Invalid mail id");
		}
	}
	
	
	System.out.println("please enter Address");
	address=scanner.next();
	
	
	
	CustomerBean bean=new CustomerBean();
	
	bean.setCustomername(customername);
	bean.setEmail(email);
	bean.setMobileNo(mobileNo);
	bean.setAddress(address);
	
	long ret=icustservice.inserCustomer(bean);
	
	System.out.println("_______________________________\n");

	 System.out.println("Do you wish to apply for a loan");
	 System.out.println("_______________________________\n");
	 System.out.println("for yes  click 1");
	 System.out.println("_______________________________\n");
	 System.out.println("for no click 2");
	 System.out.println("_______________________________\n");
	 int	choice1= scanner.nextInt();
	 switch(choice1){
	 case 1:
		 getLoanAmount();
	 case 2:
		 System.out.println("thank you for your service");
	 }
		
	}

	
	private static void getLoanAmount() {
		System.out.println("enter the loan amount");
		double p=scanner.nextDouble();
		System.out.println("enter the loan duration");
		int n=scanner.nextInt();
		double r=9.5;
		double emi=(p*r*(1+r)*n)/((1+r)*n-1);
		System.out.println("_______________________________\n");
		
		System.out.println("for loan amount "+p+"and "+n+"years duration");
		System.out.println("_______________________________\n");
		
		System.out.println("youe EMI per month will be "+emi/12);
		
		System.out.println("_______________________________\n");
		
	}
	}