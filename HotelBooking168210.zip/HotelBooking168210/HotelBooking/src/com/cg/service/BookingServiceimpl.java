package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Hotels;
import com.cg.bean.customer;
import com.cg.dao.IBookingDao;

@Service
@Transactional
public class BookingServiceimpl implements IBookingService {
	@Autowired
	IBookingDao iBookingDao;

	@Override
	public List<Hotels> allHotels() {
		// TODO Auto-generated method stub
		return iBookingDao.getAllHotels();
		
	}

	@Override
	public Hotels bookHotel(customer customer) {
		// TODO Auto-generated method stub
		return iBookingDao.bookHotel(customer);
	}

	

}
