package com.cg.service;

import java.util.List;

import com.cg.bean.Hotels;
import com.cg.bean.customer;

public interface IBookingService {
	public List<Hotels> allHotels(); 
	public Hotels bookHotel(customer customer);
	
}

