package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Hotels;
import com.cg.bean.customer;



@Repository
public class BookingDAOImpl implements IBookingDao {


	
	
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public List<Hotels> getAllHotels() {
		// TODO Auto-generated method stub
		String query="select hotel from Hotels hotel";
		TypedQuery<Hotels> tp=entitymanager.createQuery(query,Hotels.class);
		List<Hotels> lis=tp.getResultList();
		return lis;
	}

	@Override
	public Hotels bookHotel(customer customer) {
		// TODO Auto-generated method stub
		System.out.println(customer.getHotelId());
		Hotels hotels = entitymanager.find(Hotels.class, customer.getHotelId());
		int arooms=hotels.getAvailableRooms();
		arooms=arooms-1;
		hotels.setAvailableRooms(arooms);
		entitymanager.merge(hotels);
		entitymanager.persist(customer);
		entitymanager.flush();
		
		System.out.println(hotels.getName());
		
		return hotels;
	}
	

}
