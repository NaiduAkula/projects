package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Hotels;
import com.cg.bean.customer;
import com.cg.service.IBookingService;



@Controller
public class BookingController {
	
	@Autowired
	IBookingService bookingService;
	
	
	
	
	@RequestMapping(value="/home" )
	public String goHome() {
		return "index";
	}
	
	
	
		
	
	@RequestMapping("/hotels")
	public String viewHotels(Model model) {
		List<Hotels> list = bookingService.allHotels();
		model.addAttribute("hotellist", list);
		return "HotelDetails";
		
	}
	
	@RequestMapping("/bookhotel")
	public ModelAndView viewandbookhotels(int id){
		customer customer=new customer();
		ModelAndView modelAndView=new ModelAndView("hotelbooking");
		modelAndView.addObject("hotelid", id);
		modelAndView.addObject("customer", customer);
		return modelAndView;
	}
	
	
	
	@RequestMapping(value="/booking",method=RequestMethod.POST)
	public ModelAndView bookHotels(@ModelAttribute("customer") @Valid customer customer,BindingResult result) {
	
		ModelAndView modelAndView = null;
		if (!result.hasErrors()) {
			System.out.println(customer.getFromDate());
			System.out.println(customer.getToDate());
			customer.setHotelId(customer.getHotelId());
			Hotels hotels=null;
		
			
			
			hotels = bookingService.bookHotel(customer);
			 System.out.println(hotels.getName());
	
			modelAndView=new ModelAndView("bookingconfirmation","hotelsname",hotels.getName());
		}
		else {
			modelAndView = new ModelAndView("hotelbooking", "customer", customer);
			
		}
		
		return modelAndView;
		
		
	}
	
	

	
	
}

  