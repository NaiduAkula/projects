package LabBookProject;

import java.io.File;
import java.util.Scanner;

public class File92Numbers {

	public static void main(String[] args) throws Exception {
		String s= "null";
		
		File file= new File("D:\\Users\\akakula\\Desktop\\javawork\\day1\\numbers.txt");
	Scanner sc= new Scanner(file);

	while(sc.hasNext()){
	 s=sc.next();
	
	}
	 String[] ans=s.split(",");
	 int ret[]= new int[ans.length];
	for (int i = 0; i < ans.length; i++) {
		ret[i]= Integer.parseInt(ans[i]);
	}
	
	for (int i = 0; i < ret.length; i++) {
		
		if(ret[i]%2==0)
		{
		System.out.print("  " +ret[i]);
		
	}

}
}
}