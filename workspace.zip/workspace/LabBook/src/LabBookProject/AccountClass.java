package LabBookProject;

public class AccountClass {

	private long accNum;
	private double balance;
	private Person accHolder;
	private double deposit;
	private double withdraw;
	

	public AccountClass(long accNum, Person accHolder) {

		this.accNum = accNum;
		// this.balance = balance;
		this.accHolder=accHolder;
	}

	public double getBalance() {

		if (deposit > 0) {
			balance += deposit;
		}
		
		if(withdraw>0){
			balance-=withdraw;
		}
		return balance;

	}

	public long getAccNum() {

		return accNum;
	}

	public void setAccNum(long accNum) {

		this.accNum = accNum;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {

		this.deposit = deposit;
	}

	public double getWithdraw() {
		return withdraw;
	}

	public void setWithdraw(double withdraw) {

		this.withdraw = withdraw;
	}

	public void setBalance(double balance) {
		this.balance = 500+balance;
	}

	@Override
	public String toString() {
		String s = accNum + "" + balance + "" + deposit + "" + withdraw;
		return s;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

}
