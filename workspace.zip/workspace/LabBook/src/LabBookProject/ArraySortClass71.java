package LabBookProject;

import java.util.Arrays;
import java.util.Scanner;

public class ArraySortClass71 {

	public static void main(String[] args) {
		

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array size");
		int a = sc.nextInt();
		int arr[] = new int[a];

		System.out.println("enter the array numbers");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();

		}
		Arrays.sort(arr);
		//int rem[]= new int[arr.length];
		/*for (int i = 0; i < arr.length; i++) {
			while(arr[i]>0){
				 rem[i]= arr[i]%10;
				 System.out.print(rem[i]);
			arr[i]= arr[i]/10;
			}
		}
		for (int i = 0; i < rem.length; i++) {
			System.out.println(rem[i]);
		}*/
	
		
	int [] ret	=ArrayAss.getSort(arr);
	Arrays.sort(ret);
		for (int i = 0; i < ret.length;i ++) {
			System.out.println(ret[i]);
		}
	}

}
class ArrayAss{
	
	public static int[] getSort(int [] arr) {
		String s[]= new String[arr.length];
		for (int i = 0; i < arr.length; i++) {
			s[i]=String.valueOf(arr[i]);
		}
	String[] rem=new  String [arr.length];
		for (int i = 0; i < s.length; i++) {
			
				rem[i]= s[i].charAt(s[i].length()-1)+""+s[i].charAt(s[i].length()-2);
		
		
		
	}
		int ret[]= new int[rem.length];
		
	for (int j = 0; j < ret.length; j++) {
		ret[j]= Integer.parseInt(rem[j]);
	}
		return ret;
		
}
	
}