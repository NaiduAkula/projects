package LabBookProject;

import java.util.ArrayList;
import java.util.Scanner;

public class ListRemove73Class {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size for first elements ");
		int m = sc.nextInt();
		ArrayList<String> list1 = new ArrayList<String>();
		Scanner sc2 = new Scanner(System.in);
		for (int i = 0; i < m; i++) {
			list1.add(sc2.nextLine());
		}
		System.out.println("enter the size for second elements ");
		int n = sc.nextInt();
		Scanner sc1 = new Scanner(System.in);
		ArrayList<String> list2 = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			list2.add(sc1.nextLine());

		}
		ArrayList<String> e = Remove.removeElements(list1, list2);
		System.out.println(e);
	}

}

class Remove {

	public static ArrayList<String> removeElements(ArrayList<String> list1,
			ArrayList<String> list2) {
	//ArrayList<String> list3= new ArrayList<String>();
list1.removeAll(list2);
		return list1;

	}
}