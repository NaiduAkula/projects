package LabBookProject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ProjectLabBook75 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the size of array");
		int m=sc.nextInt();
		
		ArrayList<String> ar= new ArrayList<String>();
		Scanner sc1= new Scanner(System.in);
		System.out.println("enter the strings");
		for (int i = 0; i <m; i++) {
			
			ar.add(sc1.nextLine());
			
		}
		Collections.sort(ar);
		for (String string : ar) {
			System.out.println(string);
		}
		}
	}

