package LabBookProject;

import java.util.Random;
import java.util.Scanner;

public class LabBookMainAccountClass {


	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		 Person p1= new Person();
		p1.setName("smith");
		 Person p2= new Person();
		 p2.setName("kathy");
	AccountClass ac= new AccountClass(123, p1);
	ac.setAccNum(sc.nextLong());
	System.out.println(ac.getAccNum());
	
	System.out.println(ac.getAccHolder());
	
ac.setBalance(2000);
ac.setDeposit(2000);
	System.out.println(ac.getBalance());
	AccountClass ac2= new AccountClass(124, p2);
	System.out.println(ac2.getAccHolder());
	
	
	
	ac2.setBalance(3000);
	ac2.setWithdraw(2000);
	System.out.println(ac2.getBalance());
		 
		
		 
	}

}
