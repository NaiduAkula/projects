package LabBookProject;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class SquareHash73 {

	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	
	System.out.println("enter the size of the array");
	int size=sc.nextInt();
	System.out.println("enter the array of elements");
	int arg[]= new int[size];
	for (int i = 0; i <size; i++) {
		arg[i]= sc.nextInt();
	}
	HashMap<Integer, Integer> ans=SquareMap.getSquare(arg);
	for (Entry<Integer, Integer> i : ans.entrySet()) {
		System.out.println(i.getKey()+": "+i.getValue());
	}
	}

}
class SquareMap{
	public static HashMap<Integer, Integer> getSquare(int[] arg) {
		HashMap<Integer, Integer> hm= new HashMap<Integer, Integer>();
		for (int i = 0; i < arg.length; i++) {
		hm.put(arg[i], (int) Math.pow(arg[i], 2));
			
			
		}
		
		return hm;
		
		
	}
}