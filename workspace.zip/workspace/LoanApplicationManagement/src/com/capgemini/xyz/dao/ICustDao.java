package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.exception.CustomerException;

public interface ICustDao {

	long inserCust(CustomerBean bean) throws CustomerException;

}
