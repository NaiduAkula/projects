package com.capgemini.xyz.bean;

public class CustomerBean {

	private int customerId;
	private String customername;
	
	private String address;
	private String email;
	private String mobileNo;
	
	
	public CustomerBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CustomerBean [customerId=" + customerId + ", customername="
				+ customername + ", address=" + address + ", email=" + email
				+ ", mobileNo=" + mobileNo + "]";
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public CustomerBean(int customerId, String customername, String address,
			String email, String mobileNo) {
		super();
		this.customerId = customerId;
		this.customername = customername;
		this.address = address;
		this.email = email;
		this.mobileNo = mobileNo;
	}

}
