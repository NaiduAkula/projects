package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.exception.CustomerException;

public interface ICustService {

	
	boolean validatePhoneNumber(String mobileNo);

	boolean validateCustomerName(String customername);

	boolean validateMailId(String email);

	long inserCustomer(CustomerBean bean) throws CustomerException;

	

}
