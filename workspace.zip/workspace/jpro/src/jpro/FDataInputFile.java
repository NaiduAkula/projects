package jpro;

import java.io.DataInputStream;
import java.io.FileInputStream;
              
public class FDataInputFile {
	

	public static void main(String[] args) throws Exception {
	/*	byte b=1; 
		Short s=567;
		int i=10;
		float f=10.101f;
		double d=100.10001;
		char c='a';
		boolean bn= true;*/
		FileInputStream fis= new FileInputStream("D://Users/akakula/Desktop/javawork/day1/output.txt");
		DataInputStream dis= new DataInputStream(fis);
		byte b=dis.readByte();
		System.out.println(b);
		Short s=dis.readShort();
		System.out.println(s);
		int i=dis.readInt();
		System.out.println(i);
		float f=dis.readFloat();
		System.out.println(f);
		double d=dis.readDouble();
	
		System.out.println(d);
		
		char c=dis.readChar();
		System.out.println(c);
		
		boolean bn=dis.readBoolean();
		System.out.println(bn);
		dis.close();
		fis.close();
		System.out.println("primitive data written in to data.txt");
		
	}

}
