package jpro;

public class Java8InterfaceMain {

	public static void main(String[] args) {

		Java8Interface j8 = new TestJava8();
		j8.show();
		
	}

}
