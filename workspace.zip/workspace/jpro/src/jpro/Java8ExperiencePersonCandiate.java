package jpro;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Java8ExperiencePersonCandiate {

	public static void main(String[] args) {
		LinkedList<Java8Candiate> candiatelist= new LinkedList<Java8Candiate>();
		candiatelist.add(new Java8Candiate("ramesh", "java", "pune", 5));
		candiatelist.add(new Java8Candiate("raman", "java", "bangalore", 4));
		candiatelist.add(new Java8Candiate("soumya", "c#", "pune", 11));
		candiatelist.add(new Java8Candiate("raghu", "java", "chennai", 3));
		candiatelist.add(new Java8Candiate("pramod", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("trisha", "c#", "pune", 0));
		candiatelist.add(new Java8Candiate("nandan", "c++", "chennai", 0));
		candiatelist.add(new Java8Candiate("jeevan", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("priya", "java", "bangalore", 11));
		
		candiatelist.add(new Java8Candiate("priyanka", "c++", "chennai", 4));
		
		
		
		System.out.println("experience persons candiates");
		
		Set<Java8Candiate> intset	=candiatelist.stream().filter((c)->(c.getYearsofexpertise()>=2)).collect(Collectors.toSet());
		//Map<String, List<Java8Candiate>> personsCount =candiatelist.stream().collect(Collectors.groupingBy(Java8Candiate::getTechnicalExpertise));
		for (Java8Candiate java8Candiate : intset) {
			System.out.print(intset);
		}
		
		
		

	}

}
