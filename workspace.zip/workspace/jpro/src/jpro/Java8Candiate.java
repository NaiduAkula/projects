package jpro;

public class Java8Candiate {

	private String name;
	private String technicalExpertise;
	private String city;
	private int yearsofexpertise;
	public Java8Candiate(String name, String technicalExpertise, String city,
			int yearsofexpertise) {
		super();
		this.name = name;
		this.technicalExpertise = technicalExpertise;
		this.city = city;
		this.yearsofexpertise = yearsofexpertise;
	}
	@Override
	public String toString() {
		return "Java8Candiate [name=" + name + ", technicalExpertise="
				+ technicalExpertise + ", city=" + city + ", yearsofexpertise="
				+ yearsofexpertise + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTechnicalExpertise() {
		return technicalExpertise;
	}
	public void setTechnicalExpertise(String technicalExpertise) {
		this.technicalExpertise = technicalExpertise;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getYearsofexpertise() {
		return yearsofexpertise;
	}
	public void setYearsofexpertise(int yearsofexpertise) {
		this.yearsofexpertise = yearsofexpertise;
	}
	
	
}
