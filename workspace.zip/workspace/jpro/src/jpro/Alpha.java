package jpro;

public class Alpha {
}
	class Beta extends Alpha{
		
		
		
		
	}
	
	class Gama extends Alpha{
		
		
	}
	class Lambda extends Beta{ 
		}
	
	class Delta extends Beta{
	}
	
	class Zeta extends Delta{
	}
	
	
		
		
		
		
		
		
	
	
	
