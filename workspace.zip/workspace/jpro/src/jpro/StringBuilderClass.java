package jpro;

public class StringBuilderClass {
	public static void main(String[] args) {

		StringBuilder sb1 = new StringBuilder();

		System.out.println(sb1);
		System.out.println("sb1.length(): "+sb1.length());
		System.out.println("sb1.capacity(): "+sb1.capacity());
		sb1.append("capgemini ");
		System.out.println("sb1.length(): "+sb1.length());
		System.out.println("sb1.capacity(): "+sb1.capacity());
		
		sb1.append("bangalore");
		System.out.println("sb1.length(): "+sb1.length());
		System.out.println("sb1.capacity(): "+sb1.capacity());
		
        sb1.insert(10,"pvt ltd,");
		System.out.println(sb1);
		System.out.println("sb1.length(): "+sb1.length());
		System.out.println("sb1.capacity(): "+sb1.capacity());
	}


}
