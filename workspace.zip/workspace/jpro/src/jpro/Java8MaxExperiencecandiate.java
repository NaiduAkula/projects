package jpro;

import java.util.LinkedList;

public class Java8MaxExperiencecandiate {

	public static void main(String[] args) {
		LinkedList<Java8Candiate> candiatelist= new LinkedList<Java8Candiate>();
		candiatelist.add(new Java8Candiate("ramesh", "java", "pune", 5));
		candiatelist.add(new Java8Candiate("raman", "java", "bangalore", 4));
		candiatelist.add(new Java8Candiate("soumya", "c#", "pune", 11));
		candiatelist.add(new Java8Candiate("raghu", "java", "chennai", 3));
		candiatelist.add(new Java8Candiate("pramod", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("trisha", "c#", "pune", 0));
		candiatelist.add(new Java8Candiate("nandan", "c++", "chennai", 0));
		candiatelist.add(new Java8Candiate("jeevan", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("priya", "java", "bangalore", 11));
		
		candiatelist.add(new Java8Candiate("priyanka", "c++", "chennai", 4));
		
		
		
		System.out.println("candiate having maximum experience");
		Integer maxYear=InterviewRepository.getCan
		
		
		
		
		
		
	}

}
