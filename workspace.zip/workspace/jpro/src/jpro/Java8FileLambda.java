package jpro;

import java.io.File;
import java.io.FileFilter;

public class Java8FileLambda {

	public static void main(String[] args) {
		
		FileFilter filter=(File pathname)->pathname.getName().endsWith(".java");
			String path="C:\\Users\\akakula\\workspace\\jpro\\src\\jpro";
		File dir= new File(path);
		File[] con=dir.listFiles(filter);
	for (File file : con) {
		System.out.println(file);
	}
	}

}
