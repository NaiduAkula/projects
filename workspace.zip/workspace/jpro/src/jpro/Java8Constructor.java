package jpro;

public class Java8Constructor {
	public static void main(String[] args) {
		Java8Interfaceconstructor jc= Java8MethodConstructor::new;
		jc.test("naidu");
	}

}
interface Java8Interfaceconstructor{
	void test(String s);
}
class Java8MethodConstructor{
	public  Java8MethodConstructor(String s){
		System.out.println("testclass public void constructor");
	}
	
}