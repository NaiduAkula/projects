package jpro;

import java.io.Serializable;

public class TostrClass {
	public static void main(String[] args) {
		Employee e1= new Employee("101","naidu","333","dev");
		System.out.println(e1);
		System.out.println(e1.toString());
	
	}

}
class Employee{
	String empId;
	String empName;
	String depId;
	String dsg;


	// employee method
	public Employee(String empId, String empName, String depId, String dsg) {

		this.empId = empId;
		this.empName = empName;
		this.depId = depId;
		this.dsg = dsg;
	}

	 public String toString(){
		 String s=empId+" "+empName+" "+depId+" "+dsg;
		 return s;
		 
	 }
	
	 	
	 	 
	 	 public int hashCode(){
	 		 int code=empId.hashCode()+empName.hashCode()+depId.hashCode()+dsg.hashCode();
	 		 return code;
	 	 }
	 
	 
}
