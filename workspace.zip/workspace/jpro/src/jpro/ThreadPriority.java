package jpro;

public class ThreadPriority {

	public static void main(String[] args) {
		Thread t = new Thread();
		t.currentThread();
		System.out.println(t.getName() + "   Thread priority= "
				+ t.getPriority());
		t.setPriority(8);
		System.out.println(t.getName() + "   Thread priority= "
				+ t.getPriority());

		MyThread th = new MyThread();

		System.out.println("   th.isDaemon()= " + th.isDaemon());
		th.setDaemon(true);  // by setting it true we can disable the data
		th.start();
		System.out.println("   th.isDaemon()= " + th.isDaemon());

	}

}
