package jpro;

interface Java8Interface {
	
default  void show(){
		System.out.println("default method executed");
	}
	

}
class TestJava8 implements Java8Interface{
	public void  show() {}
		
	//System.out.println("bxhhchjjh");	// overriding
	}

 
 