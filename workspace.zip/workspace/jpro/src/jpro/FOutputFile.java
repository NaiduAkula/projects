package jpro;

import java.io.FileOutputStream;
import java.io.IOException;

public class FOutputFile {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos= new FileOutputStream("D://Users/akakula/Desktop/javawork/day1/output.txt");
		byte ch[]= new byte[12];
		fos.write(66);// returns the ascii character
		//fos.write(ch);;
		
	}

}
