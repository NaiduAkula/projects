package jpro;

public class ExcepAccountClass {
	public static void main(String[] args) {
		Accounts a1 = new Accounts();
		a1.accNo = "9179";
		a1.balance = 100000;
		try {
			a1.withdraw(10000);
		} catch (Exception e) {
			System.out.println("sorry no balance");
			e.printStackTrace();
		}
		System.out.println("a1.balance: "+a1.balance);
	}
}

class Accounts {
	String accNo;
	double balance;

	double withdraw(double withdrawAmount)  throws InsufficientBalanceException {
		
		if (withdrawAmount> balance){
			throw new  InsufficientBalanceException("Insufficient balance in account");
		}else {
			balance=balance-withdrawAmount;
			
		}
		return balance;

	}
	double deposit(double depositAmount){
		return balance;
	}
}

class InsufficientBalanceException extends Exception
{
	public InsufficientBalanceException();
	
}