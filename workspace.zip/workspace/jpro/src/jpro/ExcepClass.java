package jpro;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExcepClass {
public static void main(String[] args) {
	int a=10;
	int  b=0;
	int r=0;
	 System.out.println("start of the application"); 
	
	 try{
		 r=a/b;
		 System.out.println("a/b="+(a/b));
		 FileInputStream fis= new FileInputStream("D://Users/akakula/Desktop/javawork/day1/reverse.txt");
		 
	 }
	 catch(ArithmeticException e)  //it creates a object 
	 {
		// e.printStackTrace();   // it prints stacktrace order
		 System.out.println("Exception in Application");
	 }
	 catch(FileNotFoundException e)
	 {
		
		 System.out.println("filenotfound");
	 }

	 System.out.println("end of application");
}
}
