package jpro;

public class ThreadInterConnection {

	public static void main(String[] args) {
		Box box = new Box();
		ProducerThread producer = new ProducerThread(box);
		ConsumerThread consumer = new ConsumerThread(box);
		producer.start();
		consumer.start();

	}

}

class Box {
	int item;
	boolean isEmpty = true;

synchronized	public void put(int i) throws Exception {
		if (!isEmpty) {
			wait();
		}
		item = i;
		System.out.println("put :" + item);
		isEmpty = false;
		notifyAll();

	}

synchronized	public void get() throws Exception {
		if (isEmpty) {
			wait();
			

		}
		System.out.println("get :" + item);
		isEmpty = true;
		notifyAll();
	}

}

class ProducerThread extends Thread {
	Box box;

	public ProducerThread(Box box) {
		this.box = box;
	}

	@Override
	public void run() {
		try {
			int i = 0;

			while (true) {
				box.put(i++);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

class ConsumerThread extends Thread {

	
	Box box;

	public ConsumerThread(Box box) {
		this.box = box;
	}

	@Override
	public void run() {
		try {
			while (true) {
				box.get();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
