package jpro;

public class Java8MainStatic {
public static void main(String[] args) {

	Java8StaticInterface.hello();
}
}
