package jpro;

public class GenericTest3 {

	public static void main(String[] args) {
		GenericClass2<String,Integer> genDemo1= new GenericClass2<>();
		genDemo1.add("aditya",9179);
		genDemo1.getTypes();
		

	}

}
class GenericClass2<T,M>{
	T t;
	M m;
	void add(T t,M m){
		this.t=t;
		this.m=m;
		
	}
	void getTypes(){
		System.out.println(t+"            T="+t.getClass().getName());
		System.out.println(m+"            M="+m.getClass().getName());
	}
}