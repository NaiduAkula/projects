package jpro;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class Java8CandiateMain {

	public static void main(String[] args) {
		LinkedList<Java8Candiate> candiatelist= new LinkedList<Java8Candiate>();
		candiatelist.add(new Java8Candiate("ramesh", "java", "pune", 5));
		candiatelist.add(new Java8Candiate("raman", "java", "bangalore", 4));
		candiatelist.add(new Java8Candiate("soumya", "c#", "pune", 11));
		candiatelist.add(new Java8Candiate("raghu", "java", "chennai", 3));
		candiatelist.add(new Java8Candiate("pramod", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("trisha", "c#", "pune", 0));
		candiatelist.add(new Java8Candiate("nandan", "c++", "chennai", 0));
		candiatelist.add(new Java8Candiate("jeevan", "java", "mumbai", 1));
		candiatelist.add(new Java8Candiate("priya", "java", "bangalore", 11));
		
		candiatelist.add(new Java8Candiate("priyanka", "c++", "chennai", 4));
		
		
		
	
		
		
		
		Mypridicate mp1= new Mypridicate();
		Stream<Java8Candiate> candiateStream= candiatelist.stream();
		candiateStream=candiateStream.filter(mp1);
		//back to list
		List<Java8Candiate> bngcand= candiateStream.collect(Collectors.toList());
		
		for (Java8Candiate c : bngcand) {
			System.out.println(c);
		}
		
		
	bngcand =candiatelist.stream().filter((c)->(c.getCity().equals("bangalore")))
			.collect(Collectors.toList());
		
		System.out.println(bngcand);
		
		
		
		
	}

}
class Mypridicate implements Predicate<Java8Candiate>{

	@Override
	public boolean test(Java8Candiate c) {
		
		return c.getCity().equals("Bangalore");
	}
	
	
	
	
	
	
}