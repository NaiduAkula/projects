package jpro;

import java.util.Comparator;

public class Java8StreamProduct {

	
	
	public int prodId;
	public String prodName;
	public String proddesc;
	public double prodPric;
	public Java8StreamProduct(){
		
	}
	public Java8StreamProduct(int prodId, String prodName, String proddesc,
			double prodPric) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.proddesc = proddesc;
		this.prodPric = prodPric;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + prodId;
		result = prime * result
				+ ((prodName == null) ? 0 : prodName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(prodPric);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((proddesc == null) ? 0 : proddesc.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Java8StreamProduct other = (Java8StreamProduct) obj;
		if (prodId != other.prodId)
			return false;
		if (prodName == null) {
			if (other.prodName != null)
				return false;
		} else if (!prodName.equals(other.prodName))
			return false;
		if (Double.doubleToLongBits(prodPric) != Double
				.doubleToLongBits(other.prodPric))
			return false;
		if (proddesc == null) {
			if (other.proddesc != null)
				return false;
		} else if (!proddesc.equals(other.proddesc))
			return false;
		return true;
	}
/*	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProddesc() {
		return proddesc;
	}
	public void setProddesc(String proddesc) {
		this.proddesc = proddesc;
	}
	public double getProdPric() {
		return prodPric;
	}
	public void setProdPric(double prodPric) {
		this.prodPric = prodPric;
	}*/
	@Override
	public String toString() {
		return "Java8StreamProduct [prodId=" + prodId + ", prodName="
				+ prodName + ", proddesc=" + proddesc + ", prodPric="
				+ prodPric + "]";
	}
	
	/*public boolean equals (Object prod){
	Java8StreamProduct p= (Java8StreamProduct)prod;
	boolean b= (prodId==prodId)&&prodName.equals(p.prodName)&&proddesc.equals(p.proddesc)&&(prodPric==p.prodPric);
	return b;
	}
	
	public int hashCode(){
		int c= prodId+prodName.hashCode()+proddesc.hashCode()+(int)prodPric;
		return c;
	}
	*/
	class CompareProductByPrice implements Comparator<Java8StreamProduct>{

		@Override
		public int compare(Java8StreamProduct p1, Java8StreamProduct p2) {
			
			return (int)(p1.prodPric-p2.prodPric);
		}
		
	}
}
