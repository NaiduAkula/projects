package jpro;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class FCharRead {

	public static void main(String[] args) throws Exception {
		InputStreamReader isr= new InputStreamReader(System.in); // it is used to take the input
		BufferedReader reader= new BufferedReader(isr);
		String s= reader.readLine();
		System.out.println(s);

	}

}
