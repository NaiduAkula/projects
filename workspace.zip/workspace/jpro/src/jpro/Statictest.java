package jpro;

public class Statictest {
	public static void main(String[] args) {
		Test tc1 = new Test();
		Test tc2 = new Test();

		Test tc3 = new Test();
		Test tc4 = null;

		tc1.i = 67;
		tc2.i = 67;
		tc3.i = 67;
		tc4.i = 67;
		Test.i = 788; // through class name

		System.out.println("tc1.i=" + tc1.i);
		System.out.println("tc2.i=" + tc2.i);
		System.out.println("tc3.i=" + tc3.i);
		System.out.println("tc4.i=" + tc4.i);
		System.out.println("Test.i=" + Test.i);

		tc4.testStaticMethod();
		Test.testStaticMethod();
	}
}

class Test {
	int j;
	static int i;

	static void testStaticMethod() {
		System.out.println("test static " + i);
	}

}