package jpro;

import java.util.LinkedList;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Java8StreamList {
	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		ll.offer("capgemini");
		ll.offer("india");
		ll.offer("DTP");
		ll.offer("b4");
		ll.offer("bangalore");
		
		
		
		System.out.println(ll);
		//   copy the all the data into stream collection
		Stream<String> ss= ll.stream();
		
		//System.out.println("ss.count() :"+ss.count());
		//stream has already been operated upon or closed thats y commented the stream,one stream operation can perform only one operation
		
		
		
		//collecting stream data and sending to another collection like set(collectors.toset)
	Set<String> stringset =ss.collect(Collectors.toSet());
	System.out.println(stringset);
}
}