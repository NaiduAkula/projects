package jpro;

public class Testmain1 {
	public static void main(String[] args) {

		Rectangle r1 = new Rectangle(2, 2);
		
		Circle c1 = new Circle(6);
		Square s1= new Square(7);
		
		Shapes shapesA[] = new Shapes[3];
		shapesA[0] = c1;
		shapesA[1] = r1;
		shapesA[2] = s1;
		
		processShapes(shapesA);
	}

	static void processShapes(Shapes[] sArray) {
		for (int i = 0; i < sArray.length; i++) {
			sArray[i].findArea();
			sArray[i].findPerimeter();
			System.out.println("..............................");
		}

	}
}

abstract class Shapes {
	

	abstract void findArea() ;

	abstract void findPerimeter() ;

}

class Rectangle extends Shapes {
	double l;double b;
	public Rectangle(double l, double b) {
		this.l = l;
		this.b = b;

	}

	void findArea() {
		double area = l * b;
		System.out.println("area of rectangle: " + area);
	}

	void findPerimeter() {
		double perimeter = 2 * (l + b);
		System.out.println("perimeter of rectangle: " + perimeter);

	}

}

class Circle extends Shapes {
	double radius;

	public Circle(double radius) {
	this.radius=radius;
	}
	void findArea() {
		double area = 3.14 * radius * radius;
		System.out.println("area of circle: " + area);
	}

	void findPerimeter() {
		double perimeter = 2 * 3.14 * radius;
		System.out.println("perimeter of circle: " + perimeter);

	}

}
class Square extends Shapes {
	double l;


	public Square(double l) {
		this.l=l;
	}

	void findArea() {
		double area = l*l;
		System.out.println("area of square: " + area);
	}

	void findPerimeter() {
		double perimeter =4*l;
		System.out.println("perimeter of square: " + perimeter);

	}

}