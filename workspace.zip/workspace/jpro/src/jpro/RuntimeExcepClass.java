package jpro;

public class RuntimeExcepClass {
public static void main(String[] args) {
	
	int i=0;
	Integer i1=  Integer.valueOf(i);
	double d=0;
	Double dd=Double.valueOf(d);
	 
	String s="12eeff";
	Integer j= Integer.parseInt(s);
	 
	
	System.out.println(i1);
	System.out.println("j");
	
}

}
