package jpro;

public class GenericTest1 {

	public static void main(String[] args) {
		GenericClass<String> genstring= new GenericClass<String>();
		GenericClass<Integer> genint= new GenericClass<Integer>();
		
		
		
		genstring.add("string");
		System.out.println(genstring.getType());
		
		genint.add(1);
		System.out.println(genint.getType());
	//	System.out.println(genint);
		
	}
}
class GenericClass<T>{
	T o;
	void add(T o){
		this.o=o;
	}
	String getType(){
		return o.getClass().getName();
	}
	
}