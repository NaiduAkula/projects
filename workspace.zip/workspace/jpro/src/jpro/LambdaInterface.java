package jpro;

 interface LambdaInterface {
public void test();
 
}
class TestClass implements LambdaInterface{
public void test(){
	System.out.println("testClass test()");
}
}