package jpro;

public class Employeedetails {

	String empId;
	String empName;
	String depId;
	String dsg;

	// employee method
	public void employee(String empId, String empName, String depId, String dsg) {

		this.empId = empId;
		this.empName = empName;
		this.depId = depId;
		this.dsg = dsg;
	}

}
	// nonemployee method

	 class Nemployee extends Employeedetails {
		String depName;
		
		public  void employee(String empId, String empName, String depId,
				String dsg,String depName) {
	this.employee(empId, empName, depId, dsg);
	this.depName=depName;
		}
	
	// empinformation method

	 void empInfo() {
		System.out.println("empId:" + empId);
		System.out.println("empName:" + empName);
		System.out.println("depId:" + depId);
		System.out.println("dsg:" + dsg);
		System.out.println("depName:" +depName);

	}


}

	 class Emain{
			public static void main(String[] args) {

				Nemployee e = new Nemployee();
				System.out
						.println("........................employee details.....................");

			e.employee("002", "naidu", "dev", "analyst");
				e.empInfo();

				System.out
						.println("........................nonemployee details.....................");
				e.employee("002", "naidu", "dev", "analyst","sed");
		e.empInfo();
			}

		}

