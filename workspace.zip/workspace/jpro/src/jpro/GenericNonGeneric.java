package jpro;

import java.util.HashSet;

public class GenericNonGeneric {

	public static void main(String[] args) {
		HashSet hs = new HashSet();
		NonGeneric1  ng = new NonGeneric1();
		ng.add("capgemini", 1);
		ng.add("india", 2);
		ng.add("pvt", 3);
		ng.add("ltd", 4);
		ng.add("9179", 5);
		ng.add("dtp", 6);
		String s = null;
		for (int i = 0; i < 6; i++) {
			s = (String) ng.get(i);
			System.out.println(s);
		}

	}

}

class NonGeneric1 {
	Object oArray[];

	public NonGeneric1() {
		oArray = new Object[10];
	}

	void add(Object o, int i) {

		oArray[i] = o;

	}

	void remove(int i) {
		oArray[i] = null;

	}

	Object get(int i) {
		return oArray[i];
	}
}
