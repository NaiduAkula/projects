package jpro;

import java.io.*;

public class FCharBufferReader {

	public static void main(String[] args) throws Exception {
		FileReader fr= new FileReader("C:\\Users\\akakula\\workspace\\jpro\\src\\Ass\\ColourCode.java");
		
BufferedReader rd= new BufferedReader(fr);
String s= rd.readLine();
while( s!=null){
	System.out.println(s);
	s= rd.readLine();
}

	}

}
