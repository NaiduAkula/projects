package jpro;

import java.util.ArrayList;
import java.util.ListIterator;

public class CollectionListIteratorClass {
	public static void main(String[] args) {
		ArrayList<String> alsi = new ArrayList<String>();
		alsi.add("capgemini");
		alsi.add("india");
		alsi.add("DTP");
		alsi.add("b4");
		alsi.add("bangalore");

		System.out.println("**************************************");
		ListIterator<String> li = alsi.listIterator();
		String s = "";

		System.out.println("********************start_end******************");
		while (li.hasNext()) {
			s =li.next();
			System.out.println(s);
		}

		System.out.println("******************end_start********************");

		while (li.hasPrevious()) {
			s = li.previous();
			System.out.println(s);

		}

	}
}
