package jpro;


public class GenericTest4 {

	public static void main(String[] args) {
		//GenericsClass4<String> gen1= GenericsClass4<String>();
		GenericsClass4<Alpha> gen1= new GenericsClass4<Alpha>();
		GenericsClass4<Beta> gen2= new GenericsClass4<Beta>();
		GenericsClass4<Lambda> gen3= new GenericsClass4<Lambda>();
		GenericsClass4<Delta> gen4= new GenericsClass4<Delta>();
		GenericsClass4<Zeta> gen5= new GenericsClass4<Zeta>();
		
		
	}

}
class GenericsClass4< T extends Alpha>{
	T t;
	public GenericsClass4(){}
	public GenericsClass4(T t){
		super();
		this.t=t;
		
	}
	void set(T t){
		this.t=t;
		
	}
	T get(){
		return t;
	}
}