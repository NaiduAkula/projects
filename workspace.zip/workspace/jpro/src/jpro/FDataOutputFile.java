package jpro;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;



public class FDataOutputFile {

	public static void main(String[] args) throws Exception {
		byte b=1; 
		Short s=567;
		int i=10;
		float f=10.101f;
		double d=100.10001;
		char c='a';
		boolean bn= true;
		FileOutputStream fos = new FileOutputStream(
				"D://Users/akakula/Desktop/javawork/day1/output.txt");
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeByte(b);
		dos.writeShort(s);
		dos.writeInt(i);
		dos.writeFloat(f);
		dos.writeDouble(d);
		dos.writeChar(c);
		dos.writeBoolean(bn);
		dos.close();
		fos.close();
		System.out.println("primitive data written in to data.txt");
	}

}
