package jpro;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.TreeSet;

public class CollectionIterativeClass {

	public static void main(String[] args) {
		
		
		
		
		//for random order
	HashSet<String> hs = new HashSet<String>();  
		
		
		//for sorted order use tree set
	//	TreeSet<String> hs= new TreeSet<String>();
		
		
		//for selected order
		//LinkedHashSet<String> hs= new LinkedHashSet<String>();
		
		
		hs.add("capgemini");
		hs.add("india");
		hs.add("pvt ltd");
    System.out.println(hs);
    // iterator inbuiltly has local inner class which gives return values of an object
    Iterator  it= hs.iterator();
    String s= null;
    // for one element use if cond
 while(it.hasNext()){
    	s= (String)it.next();
    	System.out.println(s);
    	
    	// remove() eliminates all iterative elements
    	//it.remove();
    }
 System.out.println(hs);
 
 // for each loop
 for (String ss : hs) {
	System.out.println(ss);
}
 
 

	}

}
