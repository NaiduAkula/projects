package jpro;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class FBufferInputFile {

	public static void main(String[] args) throws Exception {
		FileInputStream fis= new FileInputStream("C:\\Users\\akakula\\workspace\\jpro\\src\\Ass\\ColourCode.java");
		BufferedInputStream bis= new BufferedInputStream(fis);
	
		int b = bis.read();
		while(b!=-1){
			System.out.print((char) b);

			b = fis.read();
		}
		System.out.println("fis.markSupported():"+fis.markSupported());

		//	System.out.println((char) b);
		
		fis.close();
		}

}
