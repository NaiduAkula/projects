package jpro;

import java.util.HashSet;
import java.util.Optional;
import java.util.stream.Stream;

import jpro.Java8StreamProduct.*;

public class JavaStreamproductMain {
static Java8StreamProduct jp;
	
	public static void main(String[] args) {
	
		
		
		Java8StreamProduct p1= new Java8StreamProduct(7179,"HDD","Hard Disk",9500);
		Java8StreamProduct p2= new Java8StreamProduct(7579,"Ram","Random Access Memory",6500);
		Java8StreamProduct p3= new Java8StreamProduct(3179,"i7","9th Gen",290);
		Java8StreamProduct p4= new Java8StreamProduct(9179,"MB","Mother Board",270);
		Java8StreamProduct p5= new Java8StreamProduct(2179,"GC","Graphics_card",250);
		Java8StreamProduct p6= new Java8StreamProduct(2179,"HP-IJ","INK-Jet Printer",500);
		Java8StreamProduct p7= new Java8StreamProduct(5179,"UPS","UnInterupeted power supply",5500);
		Java8StreamProduct p8= new Java8StreamProduct(8179,"CDD","Compact Disk drive",2240);
		
		
		
		
		
		
		Java8StreamProduct p9= new Java8StreamProduct(7145,"KBD","KeyBoard",2589);
		HashSet<Java8StreamProduct> hs= new HashSet<Java8StreamProduct>();
		hs.add(p1);
		hs.add(p2);
		hs.add(p3);
		hs.add(p4);
		hs.add(p5);
		hs.add(p6);
		hs.add(p7);
		hs.add(p8);
		hs.add(p9);
		
		
		Stream<Java8StreamProduct> pdStream= hs.stream();
		 Java8StreamProduct jp= new Java8StreamProduct();
		CompareProductByPrice cpbp=jp. new CompareProductByPrice();
		Optional<Java8StreamProduct> pdOptional= pdStream.max(cpbp);
		jp=pdOptional.get();
		System.out.println(jp);
		
		
		
		jp=hs.stream().max((o1,o2)->{return (int)(o1.prodPric-o2.prodPric);}).get();
	System.out.println(jp);

	}

}
