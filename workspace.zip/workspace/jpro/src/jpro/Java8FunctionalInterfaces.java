package jpro;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Java8FunctionalInterfaces {

	public static void main(String[] args) {
	Consumer<String> consumer=(String str)->System.out.println(str);
	consumer.accept("heelop");
	
	
	Supplier<String> supplier=()->"hello from supplier";
	consumer.accept(supplier.get());
	
	// predicate integer returns boolean
	Predicate<Integer> predicate =num->num%2==0;
	System.out.println("predicate.test(24): "+predicate.test(24));
	
	System.out.println("predicate.test(25): "+predicate.test(25));
	
	//bifunction 
	// first two integers represents input and third one is return type
	
	BiFunction<Integer, Integer, Integer> maxFunction =(x,y)->x>y? x :y;
	System.out.println(maxFunction.apply(34, 64));
	
	
	
	
	
	
	
	
	
	}

}
