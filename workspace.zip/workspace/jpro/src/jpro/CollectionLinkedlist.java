package jpro;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class CollectionLinkedlist {

	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		ll.offer("capgemini");
		ll.offer("india");
		ll.offer("DTP");
		ll.offer("b4");
		ll.offer("bangalore");
		ll.poll();
		System.out.println("********poll**********");
		
		for (String s : ll) {
			
			System.out.println(s);
		}
		LinkedList<String> ll1 = new LinkedList<String>();
		ll1.offer("capgemini");
		ll1.offer("india");
		ll1.offer("DTP");
		ll1.offer("b4");
		ll1.offer("bangalore");
ll1.peek();
System.out.println("****************peek**************");

for (String s1 : ll1) {
	
	System.out.println(s1);
}

System.out.println("************queue************");
Queue<String> ll2 = new LinkedList<String>();
ll2.offer("bangalore");
ll2.offer("b4");
ll2.offer("DTP");
ll2.offer("india");
ll2.offer("capgemini");
System.out.println(ll2);

System.out.println("************stack************");
	Stack<String> ll3 = new Stack<>();
	ll3.push("ban");
	ll3.push("b4");
	ll3.push("DTP");
	ll3.push("india");
	ll3.push("capgemini");
	System.out.println(ll3);
	
	// String cardAtTop = .pop();
	
	
	System.out.println(ll3.pop());
	System.out.println(ll3.peek());
}
}
