package jpro;

import java.io.ObjectOutputStream.PutField;

public class Anonymous {
	public static void main(String[] args) {
		TestAno1 ta1 = new TestAno1();
		MySpecification ms = new MySpecification();
		ta1.myMethod(ms);
		ta1.myMethod(new TestAno() {
			public void testMethod() {
				System.out.println("anonyms");

			}

		});

	}
}

interface TestAno {
	void testMethod();

}

class TestAno1 {
	void myMethod(TestAno ta) {
		ta.testMethod();
	}
}

class MySpecification implements TestAno {
	public void testMethod() {
		System.out.println("my speci()");

	}
}