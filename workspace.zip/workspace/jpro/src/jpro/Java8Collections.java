package jpro;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class Java8Collections {
	public static void main(String[] args) {
		String[] values={"*****","****","***","************"};
		
		List<String>  stringlist=Arrays.asList(values);
		Comparator<String> comp =(s1,s2)->Integer.compare(s1.length(),s2.length());
		Comparator<String> comp1=(s1,s2)->(s1.length()-s2.length());
	
		Collections.sort(stringlist, comp);
		for (String string : values) {
			System.out.println(string);
		}
		Collections.sort(stringlist, comp1);
		for (String string : stringlist) {
			System.out.println(string);
		}
	}

}
