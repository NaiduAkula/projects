package jpro;

public class Java8Thread {

	public static void main(String[] args) {
		Thread t1= new Thread(()->{for (int i = 0; i < 10; i++) {
			System.out.println("ThreadId= "+t.getId()+"  ThreadName="+t.getName() +"  i="+i)});
	}

}
