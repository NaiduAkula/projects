package jpro;


public class GenericMethod {

	public static void main(String[] args) {
		
String s="hello";
Beta b= new Beta();
Gama g= new Gama();


TestMethod tm= new TestMethod();
tm.testMethod(s);
tm.testMethod(1);
tm.testMethod2(s,b);
tm.testMethod3(g);




	}

}
class TestMethod{
	public <T> void testMethod(T t) {
System.out.println("*******public <T> void testMethod1(T t)*********");		
System.out.println(t.getClass().getName());
	}
	public <T1,T2> void testMethod2(T1 t1,T2 t2){
		System.out.println("*******public <T1,T2> void testMethod2(T1 t1  T2 t2)*********");
		System.out.println(t1.getClass().getName());
		System.out.println(t2.getClass().getName());
	}
	public <T extends Alpha> void testMethod3(T t){
		System.out.println("*******public <T extends AlphaGeniric> void testMethod3(T t)*********");
		System.out.println(t.getClass().getName());
	}
}