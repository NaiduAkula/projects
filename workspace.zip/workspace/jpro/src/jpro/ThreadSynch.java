package jpro;

public class ThreadSynch {
public static void main(String[] args) throws Exception {
		SharedObject so= new SharedObject();
		so.sendMessage("hello from main thread");
		
CallerThread ct1= new CallerThread( so,"hi from ct1");
CallerThread ct2= new CallerThread( so,"hi from ct2");
ct1.start();
ct2.start();
so.sendMessage("hello from mainthread");
	

	}

}
class SharedObject{
	synchronized void sendMessage(String message) throws Exception{
		System.out.print("[");
		Thread.sleep(1);
		System.out.print(message);
		Thread.sleep(1);
		System.out.println("]");
	}
}
class CallerThread extends Thread{
	SharedObject so;
	String message;
	public CallerThread(SharedObject so,String message){
		this.message=message;
		this.so=so;
	}
	public void run() {
		try {
			so.sendMessage(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}