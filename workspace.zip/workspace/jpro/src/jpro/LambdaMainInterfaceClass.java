package jpro;

public class LambdaMainInterfaceClass {
	
	public static void main(String[] args) {
		
	/*	TestClass tc= new TestClass();
		tc.test();
	*/
	
	///// for lambda 
	LambdaInterface li=()->{
		System.out.println("lamba expresioooooo");
	};
	li.test();
}
}
