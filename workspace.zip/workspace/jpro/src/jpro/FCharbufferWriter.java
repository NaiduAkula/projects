package jpro;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class FCharbufferWriter  {

	public static void main(String[] args)  throws Exception{
		FileWriter fw= new FileWriter("D://Users/akakula/Desktop/javawork/day1/output.txt");
		BufferedWriter writer= new BufferedWriter(fw);
		writer.write("capgemini pvt ltd");
writer.newLine();
writer.write("bangalore");
writer.close();
fw.close();
System.out.println("text written in your file");
	}

}
