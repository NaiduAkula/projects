package jpro;

public class GenericNonGen {
      public static void main(String[] args) {
		GenericnonClass1 ngstring= new GenericnonClass1();
		GenericnonClass1 ngint= new GenericnonClass1();
		
		
		
		ngstring.add("string");
		System.out.println(ngstring.getType());
		
		ngint.add(1);
		System.out.println(ngint.getType());
		//System.out.println(ngint);
		
	}
}
class GenericnonClass1{
Object o;
	void add(Object o){
		this.o=o;
	}
	String getType(){
		return o.getClass().getName();
	}
}
