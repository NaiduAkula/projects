package jpro;

public class ThreadSimple {

	public static void main(String[] args) throws Exception {
		MyThread t1= new MyThread();
		t1.setName("child");
		t1.start();   // start the execution by it's own
		
		
		
		MyThread t2= new MyThread();
		t2.setName("child2");
		t2.start();   // start the execution by it's own
		
		
		System.out.println("t1.isALive(): "+t1.isAlive());
		System.out.println("t2.isALive(): "+t2.isAlive());
		
		
		
		Thread t= Thread.currentThread();
		
		for (int i = 0; i < 10; i++) {
			Thread.sleep(30);
			System.out.println("ThreadId=   "+t.getId()+ "   ThreadName= "+t.getName() + "   i="+i);
		}
		t1.join();    //after the execution of these child threads main thread will wake up
		t2.join();     
		
		System.out.println("t1.isALive(): "+t1.isAlive());
		System.out.println("t2.isALive(): "+t2.isAlive());
	}

}
class MyThread extends Thread{
	
	@Override
	 
	public void run() {
		try{
		for (int i = 0; i < 10; i++) {
			Thread.sleep(10);
			System.out.println("ThreadId=   "+getId()+ "  ThreadName= "+getName()  +"   i="+i);
		}
		
		
	}
		catch(Exception e){
			e.printStackTrace();
		}
}
}