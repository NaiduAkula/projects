package jpro;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class CollectionHashMap {
	public static void main(String[] args) {
		java.util.HashMap<Integer,String> hm= new java.util.HashMap<Integer, String>();
		hm.put(1,"one");
		hm.put(2,"two");
		hm.put(3,"three");
		hm.put(4,"four");
		hm.put(5,"five");
		hm.put(6,"six");
		hm.put(7,"seven");
		hm.put(8,"eight");
		System.out.println(hm);
		hm.put(3, "threeeeeeee");
		System.out.println(hm);
		hm.put(7, "nine");
		System.out.println(hm);
		System.out.println("hm.get(1)=  "+hm.get(1));
		
		System.out.println("hm.size "+hm.size());
		// only keys
		Set<Integer> ks=hm.keySet();
		for (Integer i : ks) {
			System.out.println(i);
		}
		// only values
		
		Collection<String> va=hm.values();
		for (String s : va) {
			System.out.println(s);
		}
		
		
		Set<Map.Entry<Integer, String>> es= hm.entrySet();
		for (Map.Entry<Integer, String> me : es) {
			System.out.println(me.getKey()+":"+me.getValue());
			
		}
		
		
		
	}

}
