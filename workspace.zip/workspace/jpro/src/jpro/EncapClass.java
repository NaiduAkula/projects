package jpro;

import java.io.File;
import java.io.Serializable;

public abstract class EncapClass implements Comparable<Employee2>
{
	public static void main(String[] args) {
		Employee2 e1= new Employee2("102", "naidu" , "333" , "dev");
		Employee2 e2= new Employee2("102", "naidu", "333", "dev");
		System.out.println(e1);
		System.out.println(e1.toString());
	System.out.println(e1.equals(e2));
	System.out.println(e1.hashCode());
	
	}	
	
}

class Employee2 implements Serializable {
	private String empId;
	private String empName;
	private	String depId;
	private String dsg;  
	public transient int age;
	public transient String password; // transient which is not to used as serialize
	
	public Employee2(){
	
	}
public 	 Employee2(String empId, String empName, String depId, String dsg) {
            super();
			this.empId = empId;
			this.empName = empName;
			this.depId = depId;
			this.dsg = dsg;
		}



public boolean equals(Object obj)
{
	Employee2 e =(Employee2)obj;
	boolean b=empId.equals(e.getEmpId())&& empName.equals(e.getEmpName())
			&& depId.equals(e.getDepId()) && dsg.equals(e.getDsg());
	return b;
}
	 public String toString(){
		 String s=empId+" "+empName+""+depId+""+dsg;
		 return s;
		 
	 }
	 
	 public int hashCode(){
		 int code=empId.hashCode()+empName.hashCode()+depId.hashCode()+dsg.hashCode();
		 return code;
	 }
	 
	 
	 
	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getDepId() {
		return depId;
	}


	public void setDepId(String depId) {
		this.depId = depId;
	}


	public String getDsg() {
		return dsg;
	}


	public void setDsg(String dsg) {
		this.dsg = dsg;
	}


}