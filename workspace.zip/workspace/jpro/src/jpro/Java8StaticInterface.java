package jpro;

interface Java8StaticInterface {

	static void hello(){
		System.out.println("hello,new static method here");
	}
	
	
	
}
