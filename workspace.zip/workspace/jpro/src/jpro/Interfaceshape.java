package jpro;

public class Interfaceshape {
	public static void main(String[] args) {
	Rectangle1 r1 = new Rectangle1(2,2,6);
	Rectangle1 r2 = new Rectangle1(7,2,6);
	Rectangle1 r3 = new Rectangle1(3,2,6);
	
		Cube c1= new Cube(6, 6);
		Cube c2= new Cube(9, 6);
		
		Square1 s1= new Square1(7);
		Square1 s2= new Square1(4);
		
		Shapes1 shapesA[] = new Shapes1[6];
		Solids solidsA[]=new Solids[3];
		shapesA[0] = r1;
		
		shapesA[1] = s1;
		shapesA[2] = c1;
		
		shapesA[3] = r2;
		shapesA[4] = c2;
		shapesA[5] = s2;
		
		
		
		solidsA[0]=r1;
		solidsA[1]=r3;
		solidsA[2]=c2;
		
		
		
		processShapes(shapesA);
		processSolids(solidsA);
	}

	static void processShapes(Shapes1[] shapesA) {
		for (int i = 0; i < shapesA.length; i++) {
			shapesA[i].findArea();
			shapesA[i].findPerimeter();
			System.out.println("..............................");
		}

	}

	static void processSolids(Solids[] solidsA) {
		for (int i = 0; i < solidsA.length; i++) {
			solidsA[i].findVolume();
			
			System.out.println("..............................");
		}

	}

		
	}


 interface Shapes1{
	
	 public abstract void findArea();
	public  abstract void findPerimeter();
	 
	 
 }
  interface Solids{
	 public   abstract void findVolume(); 
  }
  
  class Rectangle1 extends Square1 implements Shapes1,Solids {
		double le;double b;double w;
		public Rectangle1(double le,double b,double w) {
		super(l);
			this.le = le;
			this.b = b;
			this.w=w;

		} 
		public void findArea() {
			double area = le * b;
			System.out.println("area of rectangle: " + area);
		}

		 public void findVolume() {
			 
			 
		double volume = le * b* w;
		System.out.println("volume of rectangle: " + volume);
	}

	public void findPerimeter() {
		double perimeter = 2 * (le + b);
		System.out.println("perimeter of rectangle: " + perimeter);

	}


		}
  
  class Cube implements Shapes1,Solids {
		double a;double e;
		public Cube(double a,double e) {
			this.a = a;
			this.e=e;

		} 
		public void findArea() {
			double area = 6*a*a;
			System.out.println("area of cube: " + area);
		}

		 public void findVolume() {
			 
			 
		double volume =a*a*a;
		System.out.println("volume of cube: " + volume);
	}

	public void findPerimeter() {
		double perimeter = 12*e;
		System.out.println("perimeter of cube: " + perimeter);

	}


		}
  
    class Square1  implements Shapes1,Solids {
	  static double l;


		public Square1(double l) {
			this.l=l;
		}

		public void findArea() {
			double area = l*l;
			System.out.println("area of square: " + area);
		}

		public void findPerimeter() {
			double perimeter =4*l;
			System.out.println("perimeter of square: " + perimeter);

		}

		@Override
		public void findVolume() {
			// TODO Auto-generated method stub
			
		}
		

	}


		
  
