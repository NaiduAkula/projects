package jpro;

public class InnerClasses {

	public static void main(String[] args) {

		OuterClass oc = new OuterClass();

		OuterClass.InnerClass ic = oc.new InnerClass();
		ic.innerTestMethod();

	}
}

class OuterClass {
	class InnerClass

	{
		void innerTestMethod() {
			System.out.println("outerclass.innerclassinnerclassTestMethod()");
		}
	}
}