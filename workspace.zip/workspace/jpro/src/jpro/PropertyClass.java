package jpro;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyClass   {

	public static void main(String[] args) throws Exception {
	FileInputStream fis= new FileInputStream("D://Users/akakula/Desktop/javawork/day1/app.properties.txt");
	Properties prop= new Properties();
	prop.load(fis);
	System.out.println("prop.get(empId): "+prop.get("empId"));
	System.out.println("prop.get(name): "+prop.get("empName"));		
	System.out.println("prop.get(dept): "+prop.get("depId"));	
	System.out.println("prop.get(dsg): "+prop.get("dsg"));	
		
		
		
	}

}
