package jpro;

public class Java8Methodreference {
public static void main(String[] args) {
	TestInterfacemethod tm= TestJava8Method :: myStaticMethod;
	
	
	tm.test();
	 
	// by using method references
	tm= new TestJava8Method() :: myMethod;
	tm.test();
	// by creating object and  by using refernce variable 
	TestJava8Method tj= new TestJava8Method();
	tm= tj :: myMethod;
	tm.test();
	
	
}
}
interface TestInterfacemethod{
	public void  test() ;
		
			
		
	
	
}
 class TestJava8Method {
	public static void  myStaticMethod() {
		System.out.println("testclass1 public void my staticMethod()");
	}
	public void myMethod(){
		System.out.println("testclas1 public void myMethod");
	}
	
	
	
}