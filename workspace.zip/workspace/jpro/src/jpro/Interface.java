package jpro;

public class Interface {

	public static void main(String[] args) {
		
		Testparent1 p1; //=new Testparent1() {
		Testparent2 p2=new Testchild1();	
		
		p1=new Testchild1();
		p1.test11();
		p1.test33();
		p2.test11();
		p2.test22();
		p2.test33();
			
		
	}
}
 
interface Testparent1
{
	public abstract void  test11();
	public abstract void  test33();
	
}

interface Testparent2 extends Testparent1
{
	public abstract void  test22();
	public abstract void  test33();
	
}

class Testchild1 implements Testparent1,Testparent2
{
	public void test11(){
		System.out.println("Testchild1 test11");
}
	public void test33(){
		System.out.println("Testchild1 test33");
}
	public void test22(){
		System.out.println("Testchild1 test22");
}
}