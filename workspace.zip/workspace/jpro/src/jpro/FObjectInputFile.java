package jpro;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class FObjectInputFile {

	public static void main(String[] args) throws Exception {
		FileInputStream fis = new FileInputStream("D://Users/akakula/Desktop/javawork/day1/output.txt");
		
		ObjectInputStream ois= new ObjectInputStream(fis);
		Employee2 e1= (Employee2)ois.readObject();
		System.out.println(e1);
		System.out.println("age :"+e1.age);
		System.out.println("password :"+e1.password);// by using transient keyword in employee2 class ,it is not showing the password data
	}

}
