package jpro;

public class ThreadRunnable {

	public static void main(String[] args) {
		RunnClass rc= new RunnClass();
		Thread t1= new Thread(rc); // for runnable interface directly class object start() doesn't work thatsyyyy we use thread object a nd pass an runnable object reference to thread object
		t1.start();
		
		Thread t= Thread.currentThread();
		for (int i = 0; i < 10; i++) {
			System.out.println("ThreadId= "+t.getId()+"  ThreadName="+t.getName() +"  i="+i);
		
		}
		/*
	Thread t1= new Thread(()->{for (int i = 0; i < 10; i++) 
			System.out.println("ThreadId= "+Thread.currentThread().getId()+"  ThreadName="+Thread.currentThread().getName() +"  i="+i);});*/

	}
	}

		
class RunnClass implements Runnable{

	@Override
	public void run() {
	try {
		Thread t= Thread.currentThread();
		for (int i = 0; i < 10; i++) {
			System.out.println("ThreadId= "+t.getId()+"  ThreadName="+t.getName() +"  i="+i);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
		
	}
	
}