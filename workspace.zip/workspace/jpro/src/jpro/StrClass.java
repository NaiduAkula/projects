package jpro;

public class StrClass {
	public static void main(String[] args) {
		String s1= "capgemini";
		String s2=new String("capgemini");
		System.out.println("s1.length(): "+ s1.length());
		System.out.println("s1.substring(3,7): "+s1.substring(3,7));
		System.out.println("s1.indexOf(emi): "+ s1.indexOf("emi"));
		System.out.println("s1.endsWith(ini): "+s1.endsWith("ini") );
		System.out.println("s1.startsWith(cap): "+ s1.startsWith("cap"));
		System.out.println("s1.isEmpty(): "+ s1.isEmpty());
		System.out.println("s1.charAt(7): "+s1.charAt(7));
		System.out.println("s1.compareTo(s2): "+ s1.compareTo(s2));
		System.out.println("s1.concat(Bangalore): "+s1.concat("Bangalore") );
		System.out.println("s1.toUpperCase(): "+ s1.toUpperCase());
		System.out.println("s1.toLowerCase(): "+ s1.toLowerCase());
		System.out.println("s1.endsWith(inii): "+s1.endsWith("inii") );
		System.out.println("s1.startsWith(Cap): "+ s1.startsWith("Cap"));
		
		
		
		
		
	}

}
