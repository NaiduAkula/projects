package jpro;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class FObjectOutputFile {

	public static void main(String[] args) throws Exception {
		 Employee2 e1= new Employee2
				 ("9158", "naidu", "Trainer","training");
		 e1.age=56;
		 e1.password="gddtu";
		 
		 System.out.println(e1);
		 System.out.println("age :"+e1.age);
		 System.out.println("password :"+e1.password);
		 FileOutputStream fos= new FileOutputStream("D://Users/akakula/Desktop/javawork/day1/output.txt");
		 ObjectOutputStream oos= new ObjectOutputStream(fos);
		 oos.writeObject(e1);
		 System.out.println("employee2 e1 serialized to D://Users/akakula/Desktop/javawork/day1/output.txt: ");

	}

}
