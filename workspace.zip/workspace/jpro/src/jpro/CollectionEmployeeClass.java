package jpro;

import java.util.HashSet;

public class CollectionEmployeeClass {
	public static void main(String[] args) {
		Employee2 e1 = new Employee2("723883", "naidu", "hhhdh", "dev");
		Employee2 e2 = new Employee2("723884", "naidu1", "hhhdh1", "dev1");
		Employee2 e3 = new Employee2("723885", "naidu2", "hhhdh2", "dev2");
		Employee2 e4 = new Employee2("723886", "naidu3", "hhhdh3", "dev3");
		Employee2 e5 = new Employee2("723887", "naidu4", "hhhdh4", "dev4");
		Employee2 e6 = new Employee2("723888", "naidu5", "hhhdh5", "dev5");
		Employee2 e7 = new Employee2("723889", "naidu6", "hhhdh5", "dev5");
		Employee2 e8 = new Employee2("723890", "naidu7", "hhhdh5", "dev5");
		Employee2 e9 = new Employee2("723891", "naidu8", "hhhdh5", "dev5");
		Employee2 e10 = new Employee2("723888", "naidu5", "hhhdh5", "dev5");
		Employee2 e11 = new Employee2("723883", "naidu", "hhhdh", "dev");
		// CompareByName cbn= new CompareByName();
		HashSet<Employee2> hs = new HashSet<Employee2>();
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
		hs.add(e6);
		hs.add(e1);
		hs.add(e7);
		hs.add(e8);
		hs.add(e9);
		hs.add(e10);
		hs.add(e11);

		for (Employee2 e : hs) {
			System.out.println(e);
		}
	}
}
/*
 * class CompareByName implements Comparator<Employee2>{
 * 
 * 
 * public int compare(Employee2 e1,Employee2 e2) { return
 * e1.getEmpName().compareTo(e2.getEmpName());
 * 
 * }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * }
 */