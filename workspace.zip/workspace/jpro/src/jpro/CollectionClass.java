package jpro;

import java.util.*;

public class CollectionClass {
	public static void main(String[] args) {

		HashSet hs = new HashSet();
		hs.add("capgemini");
		hs.add("india");
		hs.add("pvt ltd");

		HashSet hs1 = new HashSet();
		hs1.add("Java");
		hs1.add("jee");
		hs1.add("angular ");
		System.out.println(hs1);

		System.out.println(hs);
		System.out.println("hs.size():" + hs.size());
		hs.remove("pvt ltd");
		System.out.println(hs);
		System.out.println("hs.contains(india): " + hs.contains("india"));
		System.out.println(hs.isEmpty());
/*		// add all elements to another
		hs.addAll(hs1);
		System.out.println(hs);

		// removes the matched elements
		hs.removeAll(hs1);
		System.out.println(hs);

		// compare the elements if all the elements present in one another it
		// returns true
		 hs.containsAll(hs1);
		System.out.println(hs.containsAll(hs1));

		// it retains only another elements ,for to use this eliminate removeAll
		// method
		hs.retainAll(hs1);
		System.out.println("hs :" + hs);

		hs.clear();
		System.out.println(hs.isEmpty());
		System.out.println(hs);                 */
 
		System.out.println(hs);
		Object oArray[] = hs.toArray();
		
		String s= "null";
		 for (int i = 0; i < oArray.length; i++) {
			 s=(String)oArray[i];
			 System.out.println(s);
		}
		
		System.out.println("....................................");
		
		// for second toArray() we want to create a object
		String sArray[]= new String[hs.size()];
		hs.toArray(sArray);
		for (int i = 0; i < sArray.length; i++) {
			s=sArray[i];
			System.out.println(s);
		}
		
		
	}
}