package jpro;




public class InnerClasses1 {
public static void main(String[] args) {
	
	
	OuterClass1 oc= new OuterClass1();
	oc. newMethod();
	
			
	
}
}
 class OuterClass1
 {
	 void newMethod(){
		 class InnerClass1{
			 void testLocalInnerClassMethod(){
				 System.out.println("newmethod");
			 }
		 }
		 InnerClass1 ic1=new InnerClass1();
		 ic1.testLocalInnerClassMethod();
		 
	 }
 }