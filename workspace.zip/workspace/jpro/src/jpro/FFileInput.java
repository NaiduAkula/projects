package jpro;

import java.io.FileInputStream;

public class FFileInput {

	public static void main(String[] args) throws Exception {
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\akakula\\workspace\\jpro\\src\\Ass\\ColourCode.java");

	/*	int b = fis.read();
		while(b!=-1){
			System.out.print((char) b);

			b = fis.read();
		}
		System.out.println("fis.markSupported():"+fis.markSupported());

		//	System.out.println((char) b);
		
		fis.close();*/
		
		//byte b[]= new byte[36];
//		fis.read(b);
//		for (byte c : b) {
//			System.out.println((char)c);
//		}
		byte bArray[]= new byte[16];
		int byt=0;
		byt= fis.read(bArray);
		while(byt>0){
			for(int i=0;i<byt;i++){
				System.out.println(bArray[i]);
			}
			byt=fis.read(bArray);
		}
		
		
	}

}
