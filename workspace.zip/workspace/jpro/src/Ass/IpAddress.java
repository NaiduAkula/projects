package Ass;


	import java.util.Scanner;

	public class IpAddress {

		public static void main(String[] args) {

			System.out.println("enter the array of string");

			Scanner sc1 = new Scanner(System.in);
			String s1 = null;
			String s = sc1.nextLine();

			if (s.matches("[0-9]{12}+")) {
				s1 = s;
			} else {
				System.out.println("given data is not in a particular order");
			}
			int res = TestMain7.ipValidator(s1);
			if (res == 1) {
				System.out.println("valid");
			} else {
				System.out.println("invalid");
			}

		}

	}

	class TestMain7 {
		static int re = 0;

		public static int ipValidator(String s1) {
			/*char[] ch = new char[3];
			char[] ch1 = new char[3];
			char[] ch2 = new char[3];
			char[] ch3 = new char[3];
			

			for (int i = 0; i < 3; i++) {
				ch[i] = s1.charAt(i);
			}
			for (int i = 3; i < 6; i++) {
				ch1[i] = s1.charAt(i);
			}
			for (int i = 6; i < 9; i++) {
				ch2[i] = s1.charAt(i);
			}
			for (int i = 9; i < 12; i++) {
				ch3[i] = s1.charAt(i);
			}*/
			
			
			String ch1 = s1.charAt(0)+""+s1.charAt(1)+""+s1.charAt(2);
			String ch2 = s1.charAt(3)+""+s1.charAt(4)+""+s1.charAt(5);
			String ch3 = s1.charAt(6)+""+s1.charAt(7)+""+s1.charAt(8);
			String ch4 = s1.charAt(9)+""+s1.charAt(10)+""+s1.charAt(11);
			
			
			
			
		/*	String a=String.valueOf(ch);
			String s11 = a.replaceAll("\\s+", "");
			String b=	String.valueOf(ch1);
			String s12 = b.replaceAll("\\s+", "");
			String c=String.valueOf(ch2);
			String s13 = c.replaceAll("\\s+", "");
			String d=String.valueOf(ch3);
			String s14 = d.replaceAll("\\s+", "");*/
			// character array to integer
			int num1 = Integer.parseInt(ch1);
			int num2 = Integer.parseInt(ch2);
			int num3 = Integer.parseInt(ch3);
			int num4 = Integer.parseInt(ch4);
			if (((num1 >= 0) && (num1 <= 255)) && ((num2 >= 0) && (num2 <= 255)) && ((num3 >= 0) && (num3 <= 255))&&((num4 >= 0) && (num4 <= 255))) {
				 re = 1;
			} else {
				 re = -1;
			}
	return re;
		}


}
