package Ass;



import java.util.Arrays;
import java.util.Scanner;

public class FlushCharacters {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String a = sc.nextLine();
		String s1 = a.replaceAll("\\s+", "");
		String str = TestMain6.getSpecialCharacters(s1);
		System.out.println(str);
	}

}

class TestMain6 {
	public static String getSpecialCharacters(String s1) {
		String ret;
		int j = 0;

		char[] st = new char[50];
		for (int i = 0; i < s1.length(); i++) {
			char a = s1.charAt(i);
			if (!Character.isAlphabetic(a)) {
				st[j] = a;
				j++;
			}
		}

		ret = String.copyValueOf(st);
		return ret;

	}
}


