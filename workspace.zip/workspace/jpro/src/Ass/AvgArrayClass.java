package Ass;

import java.util.Arrays;
import java.util.Scanner;

public class AvgArrayClass {
	public static void main(String[] args) {
		int sum = 0;
		int near = 0;
		int diff1;
		int diff2;

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the array size");
		int a = sc.nextInt();
		int arr[] = new int[a];

		System.out.println("enter the array numbers");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();

		}
		Arrays.sort(arr);

		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		int avg = sum / arr.length;
		System.out.println("avg of array is :" + avg);

		for (int i = 0; i < arr.length; i++) {

			for (int j = 1; j < arr.length; j++) {

				if ((arr[i] < avg) && (arr[j] > avg)) {
					diff1 = Math.abs(arr[i] - avg);
					diff2 = Math.abs(arr[j] - avg);
					if (diff1 < diff2) {
						System.out.println("nearest number is :" + arr[i]);
					} else if (diff1 > diff2) {

						System.out.println("nearest number is :" + arr[j]);
					} 

				}
	
				
				else if ((arr[i] == avg) && (arr[j] == avg)) {
					System.out.println("nearest number is :" + arr[i]);

				}
				i++;
			}

		}
	}
}
