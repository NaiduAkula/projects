package Ass;

import java.util.*;

public class ArrReverseClass {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int a1 = sc.nextInt();
		int array[] = new int[a1];
		System.out.println("enter the array numbers");
		for(int i=0;i<array.length;i++){
			array[i]=sc.nextInt();
		}
		Arrays.sort(array);
		
	System.out.println("enter the number");
	int num = sc.nextInt();

		int e = UserMainCode.addAndReverse(array,num);
		System.out.println(e);
	}

}

class UserMainCode {
	static int d;
	static int i;
	static int sum=0;
	static int rev;

	public static int addAndReverse(int array[], int num) {
		
		
		for (int i = 0; i < array.length; i++) {
			
			if (num < array[i]) {
				sum=sum+array[i];
			}
				
		}
		 while(sum!= 0) {
	            int digit = sum % 10;
	            rev = rev * 10 + digit;
	            sum /= 10;
	        }
		
		
		
		
			int d =rev ;
			return d;
			
		//	System.out.println(d);

		
		
		
		//return d;
	}
}