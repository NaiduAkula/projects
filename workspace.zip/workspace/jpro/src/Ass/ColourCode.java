package Ass;

import java.util.Scanner;

public class ColourCode {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String a = sc.nextLine();
		String s1 = a.replaceAll("\\s+", "");
		int re = TestMain5.colourValidate(s1);
		if (re == 1) {
			System.out.println("valid");
		} else {
			System.out.println("invalid");
		}

	}
}

class TestMain5 {
	static int num = 0;

	public static int colourValidate(String s1) {

		if (s1.charAt(0) == '#') {

			// checking these elements present in given string
			if ((s1.matches("[A-F0-9#]+") == true) && s1.length() < 8) {

				// &&(s1.matches("[#]"))){
				num = 1;
			}

			else {
				num = -1;
			}

		}
		return num;
	}
}
