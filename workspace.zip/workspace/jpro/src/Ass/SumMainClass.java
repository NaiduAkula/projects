package Ass;

import java.util.Scanner;

public class SumMainClass {
	public static void main(String[] args) {
		System.out.println("***************************");
		int e=GetLuckySum.sum();
		System.out.println(e);
	}

	

}

 class GetLuckySum {
	
static  int d1;

	public static int sum() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter 3 numbers");
		 int a1 =sc.nextInt();

		 int b1 =sc.nextInt();
		 int c1 =sc.nextInt();
		
		
		
		if (a1== 13) {
			int d1 = c1;
			return d1;
		} else if (a1 != 13) {
			if (b1 == 13) { 
				int d1=a1;
				return d1;
			}
			else if (c1==13) {
				int d1= a1+b1;
				return d1;
				
			}
			else  {
				int d1= a1+b1+c1;
				return d1;
			}

			}
		
		return d1;

	}
}