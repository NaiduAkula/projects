package Ass;


	import java.util.Scanner;

	public class AddNumClass {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the string");
			String s=sc.nextLine();
			int d=TestAdd.revNum(s);
			int sum=0;
			if(d>0) {
			while (d>0) {
			int	rem=d%10;
			 sum +=rem;
				d/=10;
			
			}
			System.out.println(sum);
			}
			else {
				System.out.println(sum);
			}

	}
	}
	  class TestAdd
	 {
		static int rem=0;
		static int  sum=0;
		
		 static int sum2=0; 
		 public static int revNum(String s) {
			 
			int num=Integer.parseInt(s);
			while(num>0)
			{
				  rem=num%10;
				sum+=rem;
				num/=10;
				
			}
			
			return sum;
			
		}
	 
	 }


