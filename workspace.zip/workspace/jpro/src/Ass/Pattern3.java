package Ass;

public class Pattern3 {
	
	
	public static void main(String args[]){
	    int i,j,k=1,l,n=7;
	    for(i=n;i>0;i--){
	        
	        for(j=i;j>n/2;j--){
	            System.out.print(" ");
	            
	            }
	        for(l=0;l<k;l++){
	            System.out.print("*");
	            
	            }
	        k=k+2;
	        for(l=j;l>=0;l--){
	            System.out.print(" ");
	            
	            }
	        System.out.println("");
	    }
	}
	 
	}
	 
	 
	


