package Ass;

public class pattern1 {
	
		public static void main(String args[]){
		    int i,j,k,n=10;
		    for(i=0;i<n;i++){
		        for(j=0;j<=i;j++){
		            System.out.print("*");
		            
		            }
		        
		        System.out.println("");
		    }
		}
		 
		}
		 

