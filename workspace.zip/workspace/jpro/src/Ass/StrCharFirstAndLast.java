package Ass;

	import java.util.Scanner;

	//import com.sun.org.apache.regexp.internal.recompile;

	public class StrCharFirstAndLast {

		
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			System.out.println("enter the array size");
			int a1 = sc.nextInt();
			String arr[] = new String[2];
			System.out.println("enter the array of strings");
			Scanner sc1 = new Scanner(System.in);

			for (int j = 0; j < arr.length; j++) {
				arr[j] = sc1.nextLine();
			}
				Boolean s=TestMain3.isEqual(a1, arr);
				System.out.println(s);
			

		}

	}

	class TestMain3 {
		static String s;
		static String ch2;
		public static Boolean isEqual(int a1, String[] arr) {

			 //for (int i = 0; i < arr.length; i++) {
			char ch =arr[0].charAt(1);
			String s=Character.toString(ch);
			String ch2 = Character.toString(arr[1].charAt(arr[1].length()-2)) ;
			if (s.equalsIgnoreCase(ch2)) {
				return true;
			}

			else {
				return false;

			}

			 }
		}



