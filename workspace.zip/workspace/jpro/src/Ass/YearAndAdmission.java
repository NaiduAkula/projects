package Ass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class YearAndAdmission {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("enter the size for first elements ");
		int m = sc.nextInt();
		ArrayList<Integer> ar1 = new ArrayList<Integer>();
		int n = m + m;
		System.out.println("enter the year and admission count");
		for (int i = 0; i < n; i++) {
			ar1.add(sc.nextInt());
		}
		System.out.println("*****************************");
		int s = TestMain9.getYear(ar1);
		System.out.println(s);
	}
}

class TestMain9 {
	static int a = 0;

	public static int getYear(ArrayList<Integer> ar1) {
		int b = Collections.max(ar1);
		int c = ar1.indexOf(b);
		a = ar1.get(c - 1);

		return a;

	}
}