package Ass;

public class Pattern2 {
	public static void main(String args[]){
	    int i,j,k,n=10;
	    for(i=0;i<n;i++){
	        for(j=0;j<n-i;j++){
	            System.out.print(" ");
	            
	            }
	        for(k=j;k<n;k++){
	            System.out.print("*");
	            
	            }
	        System.out.println("");
	    }
	}
	 
	}

