package Ass;

import java.util.Scanner;

public class ConcatStringArray {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the array size");
		int a1=sc.nextInt();
		String arr[]=new String[a1];
		System.out.println("enter the array of strings");
		Scanner sc1= new Scanner(System.in);
		
		for (int j = 0; j < arr.length; j++) {
			arr[j]=sc1.nextLine();
		}
		String[] str1=TestMain2.concatArray(arr);
		for (int i = 0; i < str1.length; i++) {
			System.out.print(str1[i]);
			
		}
	}

}
class TestMain2{
	public static String[] concatArray(String s[]) {
char[] k= new char[s.length];
		for (int i = 0; i < s.length; i++) {
			k[i]=s[i].charAt(s[i].length()-1);
		
		}
		
		
		// copy the char to string
	String ss=String.copyValueOf(k);
	// split the string into string array
	String[] sss=ss.split("");
	//String[] str=new String[sss.length];
		//for (int i = 0; i < sss.length; i++) {
		//	 str[i]=sss[i];
	
			
		//}
		
		return sss;		
		
		
		
		
	}
}

