package Ass;

import java.util.Scanner;

public class Eliminate10InArray {
	
public static void main(String[] args) {
	
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the size of array");
	int a= sc.nextInt();
	int[] ar1= new int[a];
	System.out.println("enter the array elements");
	for (int i = 0; i < ar1.length; i++) {
		ar1[i]=sc.nextInt();
	}
	int ans[]=ArrayEliminate.removeTens(ar1);
	for (int i = 0; i < ans.length; i++) {
		System.out.println(ans[i]);
	}
	
}
}
class ArrayEliminate{
	public static int[] removeTens(int i[]) {
		int re[]= new int[i.length];
		int k = 0;
		for (int j = 0; j < re.length; j++) {
			if(i[j]!=10){
				re[k]=i[j];
				k++;
		}
			
		}
		return re;
	}
}