package Ass;


	import java.util.Scanner;

	public class CountAlpha {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the strings");
			String a = sc.nextLine();
			String s1 = a.replaceAll("\\s+", "");

			String b = sc.nextLine();
			String s2 = b.replaceAll("\\s+", "");

			int d = Testmain4.countAlpha(s1, s2);
			System.out.println(d);
		}
	}

	class Testmain4 {
		static int re = 0;

		public static int countAlpha(String s1, String s2) {

			// int count = 0;

			String str = "";
			
			while (s1.length() > 0) {
				char ch = s1.charAt(0);
				str += ch;
				s1 = s1.replace(ch + "", ""); // Replacing all occurrence of the current character by a spaces
			}

			String str2 = "";

			while (s2.length() > 0) {
				char ch1 = s2.charAt(0);
				str2 += ch1;
				s2 = s2.replace(ch1 + "", ""); // Replacing all occurrence of the current character by a spaces
			}
			
			

			for (int i = 0; i < str.length(); i++) {
				int count = 0;
				for (int j = 0; j < str2.length(); j++) {
					if (str.charAt(i) == str2.charAt(j)) {
						count++;

					}

				}
				if (count == 1) {
					re++;

				}

			}

			return re;

		}
	}


