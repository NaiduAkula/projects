package Ass;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size for first elements ");
		int m = sc.nextInt();
		ArrayList<Integer> ar1 = new ArrayList<Integer>();
		for (int i = 0; i < m; i++) {
			ar1.add(sc.nextInt());
		}
		System.out.println("enter the size for second elements ");
		int n = sc.nextInt();
		ArrayList<Integer> ar2 = new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			ar2.add(sc.nextInt());
		}
ArrayList<Integer> ans=TestMain8.arrayListSubstractor(ar1,ar2);
for (int i : ans) {
	System.out.println(i);
}
	}

}
class TestMain8{
	
	public static ArrayList<Integer> arrayListSubstractor(ArrayList<Integer> ar1,ArrayList<Integer> ar2) {
		
		
		ArrayList<Integer> ret = new ArrayList<> ();
		for (Integer s : ar1) {
		    if (!ar2.contains(s)) ret.add(s);
		}
		for (Integer s : ar2) {
		    if (!ar1.contains(s)) ret.add(s);
		}
		
		
		return ret;
		
		
		/*ar1.retainAll(ar2);
		
		ArrayList<Integer> arr3= new ArrayList<Integer>();
		
		arr3.addAll(ar1);
		arr3.addAll(ar2);
		
		
		 /*ar1.removeAll(ar2);
		ArrayList<Integer> ch=ar1;
int[] arr = new int[ch.size()];
		for(int i = 0; i < ch.size(); i++) {
		    arr[i] = ch.get(i);
		}
		ar2.removeAll(ar1);
		ArrayList<Integer> ch1=ar2;
		int[] arr1 = new int[ch1.size()];
		for(int i = 0; i < ch1.size(); i++) {
		    arr1[i] = ch1.get(i);
		}
		 str=arr+""+arr1;
		
		//int re= Integer.parseInt(str);
		
		
		
		int ret[]= new int[str.length()];
		for (int i = 0; i < str.length(); i++) {
			ret[i]= str.charAt(i);
			
		}
		return ret;
		
		
	}
	public String toString() {
		String s= str;
		return s;
	}*/
}
}