package Ass;


	import java.util.Scanner;

	public class StringManipulation {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			String s = sc.nextLine();
			String d = TestMain.SimpleStr(s);
			System.out.println(d);

		}

	}

	class TestMain {
		
		static String str="";

		public static String SimpleStr(String s) {
			char[] ch = new char[10];
			for (int i = 0; i < s.length(); i++) {
				ch[i] = s.charAt(i);

			}
			String a = new String(ch);
			// return a;

			if (a.charAt(0) == 'j') {

				if (a.charAt(1) == 'b') {

					str = a.charAt(0) + "" + a.charAt(1) + "" + a.substring(2, a.length());

				}
				else  {

					if (a.charAt(1) != 'b') {
						
						str = a.charAt(0)+""+a.substring(2, a.length());

					}

				} 

			}

			
			else if (a.charAt(0) != 'j') {

				if (a.charAt(1) != 'b') {

					str = a.substring(2, a.length());

				}

			}

			return str;
		}
	}


