package JunitPackage;

public class Calc {
	 
			public String s;

		public	double add(double v1, double v2) throws Exception {
				if (v1 > 10000 || v1 < -10000) {
					throw new Exception(
							"Input v1 Out of Range should be between -10000 to 10000 ");
				}
				if (v2 > 10000 || v2 < -10000) {
					throw new Exception(
							"Input v2 Out of Range should be between -10000 to 10000 ");
				}
				double result = v1 + v2;
				if (result > 10000 || result < -10000) {
					throw new Exception(
							"Output  Out of Range should be between -10000 to 10000 ");
				}
				return result;
			}

			public double subtract(double in1, double in2) throws Exception {
				if (in1 > 10000 || in1 < -10000) {
					throw new Exception(
							"Input in1 Out of Range should be between -10000 to 10000 ");
				}
				if (in2 > 10000 || in2 < -10000) {
					throw new Exception(
							"Input in2 Out of Range should be between -10000 to 10000 ");
				}
				double result = in1 - in2;
				if (result > 10000 || result < -10000) {
					throw new Exception(
							"Output  Out of Range should be between -10000 to 10000 ");
				}
				return result;
			}

			public double multiply(double in1, double in2) throws Exception {
				if (in1 > 10000 || in1 < -10000) {
					throw new Exception(
							"Input in1 Out of Range should be between -10000 to 10000 ");
				}
				if (in2 > 10000 || in2 < -10000) {
					throw new Exception(
							"Input in2 Out of Range should be between -10000 to 10000 ");
				}
				double result = in1 * in2;
				if (result > 10000 || result < -10000) {
					throw new Exception(
							"Output  Out of Range should be between -10000 to 10000 ");
				}
				return result;
			}

			public double divide(double in1, double in2) throws Exception {
				if (in1 > 10000 || in1 < -10000) {
					throw new Exception(
							"Input in1 Out of Range should be between -10000 to 10000 ");
				}
				if (in2 > 10000 || in2 < -10000) {
					throw new Exception(
							"Input in2 Out of Range should be between -10000 to 10000 ");
				}
				double result = in1 / in2;
				if (result > 10000 || result < -10000) {
					throw new Exception(
							"Output  Out of Range should be between -10000 to 10000 ");
				}
				return result;	}
		}


