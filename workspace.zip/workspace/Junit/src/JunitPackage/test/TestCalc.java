package JunitPackage.test;

import JunitPackage.Calc;

public class TestCalc {
	public static void main(String[] args) {
		double in1=30;
		double in2=10;
		double expected=40;
		
		double actual=0;
		Calc c1=new Calc();
		try {
			actual=c1.add(in1,in2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(actual==expected){
			System.out.println("Pass");
		}
		else{
			System.out.println("Fail");
		}
		in1=100;
		in2=50;
		expected=50;
		actual=0;
		try {
			actual=c1.subtract(in1,in2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(actual==expected){
			System.out.println("Pass");
		}
		else{
			System.out.println("Fail");
		}
		
	}
}


