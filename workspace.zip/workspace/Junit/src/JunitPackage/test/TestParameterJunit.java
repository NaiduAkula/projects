package JunitPackage.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import JunitPackage.Calc;

@RunWith(Parameterized.class)
public class TestParameterJunit {

	private double in1;
	private double in2;
	private double out;
	
	
	@Parameterized.parameters
	public static Collection data(){
		return Arrays.asList(new object[][]{{10,20,30},{30,70,40},{70,40,10}});
		
	}
	public TestParameterJunit(double in1,double in2,double out){
		this.in1=in1;
		this.in2=in2;
		this.out=out;
	}
	
	@Test
	public void  testAdd() throws Exception{
		Calc calci= new Calc();
		assertEquals(out,calci.add(in1, in2),0);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
