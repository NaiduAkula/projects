package JunitPackage.test;


	import org.junit.runner.RunWith;
	import org.junit.runners.Suite;
	import org.junit.runners.Suite.SuiteClasses;
	@RunWith(Suite.class)
	@SuiteClasses({TestCalcAdd.class,TestCalcSub.class,TestCalcMul.class,TestCalcDiv.class})
	public class SuiteClass {

}
