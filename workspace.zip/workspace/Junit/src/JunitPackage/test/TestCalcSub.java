package JunitPackage.test;



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import JunitPackage.Calc;

public class TestCalcSub {
	
	static Calc calc;

	@BeforeClass
	public static void initCalc() {
		calc = new Calc();
	}

	@AfterClass
	public static void unInitCalc() {
		calc = null;
	}

	@Before
	public void setUp() {
		//System.out.println("Before Every test");
		calc.s = "";
	}

	@After
	public void discard() {
		System.out.println("After Every Test");
	}

	@Test
	public void testSubOverflow1() {
		double in1 = 10001;
		double in2 = 20;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Input in1 Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

	@Test
	public void testSubOverflow2() {
		double in1 = 10;
		double in2 = 20000;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Input in2 Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

	@Test
	public void testSubOverflow3() {
		double in1 = 10;
		double in2 = -9999;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Output  Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

	@Test
	public void testSubOverflow4() {
		double in1 = -100001;
		double in2 = 20;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Input in1 Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

	@Test
	public void testSubOverflow5() {
		double in1 = 10;
		double in2 = -200000;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Input in2 Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

	@Test
	public void testSubOverflow6() {
		double in1 = -9999;
		double in2 = 20;
		try {
			calc.subtract(in1, in2);
		} catch (Exception e) {
			assertEquals(
					"Output  Out of Range should be between -10000 to 10000 ",
					e.getMessage());
		}
	}

}
