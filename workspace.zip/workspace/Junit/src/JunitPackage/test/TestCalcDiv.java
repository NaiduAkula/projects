package JunitPackage.test;


	import static org.junit.Assert.*;

import org.junit.Test;
import JunitPackage.Calc;
	
	public class TestCalcDiv {
		static Calc calc;
		
		@Test
		public void testDivOverflow1() {
			double in1 = 10001;
			double in2 = 20;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input in1 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testDivOverflow2() {
			double in1 = 10;
			double in2 = 20000;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input in2 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testDivOverflow3() {
			double in1 = 9999;
			double in2 = 00.01;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Output  Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testDivOverflow4() {
			double in1 = -100001;
			double in2 = 20;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input in1 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testDivOverflow5() {
			double in1 = 10;
			double in2 = -200000;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input in2 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testDivOverflow6() {
			double in1 = -9999;
			double in2 = 0.01;
			try {
				calc.divide(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Output  Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

	
	}

