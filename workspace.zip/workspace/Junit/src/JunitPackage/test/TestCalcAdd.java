package JunitPackage.test;


	
	import static org.junit.Assert.*;

	import org.junit.After;
	import org.junit.AfterClass;
	import org.junit.Before;
	import org.junit.BeforeClass;
	import org.junit.Test;

	import JunitPackage.Calc;

	public class TestCalcAdd {
		
		static Calc calc;

		@BeforeClass
		public static void initCalc() {
			calc = new Calc();
		}

		@AfterClass
		public static void unInitCalc() {
			calc = null;
		}

		@Before
		public void setUp() {
			//System.out.println("Before Every test");
			calc.s = "";
		}

		@After
		public void discard() {
			System.out.println("After Every Test");
		}
		
		@Test
		public void testAdd() {
			double in1 = -9999;
			double in2 = 20;
			double expected = -9979;
			try {
				assertEquals(expected, calc.add(in1, in2), 0);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Test
		public void testAddOverflow1() {
			double in1 = 10001;
			double in2 = 20;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input v1 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testAddOverflow2() {
			double in1 = 10;
			double in2 = 20000;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input v2 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testAddOverflow3() {
			double in1 = 10;
			double in2 = 9999;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Output  Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testAddOverflow4() {
			double in1 = -100001;
			double in2 = 20;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input v1 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testAddOverflow5() {
			double in1 = 10;
			double in2 = -200000;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Input v2 Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

		@Test
		public void testAddOverflow6() {
			double in1 = -9999;
			double in2 = -2020;
			try {
				calc.add(in1, in2);
			} catch (Exception e) {
				assertEquals(
						"Output  Out of Range should be between -10000 to 10000 ",
						e.getMessage());
			}
		}

	}

