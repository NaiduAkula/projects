package logon;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestMainClass {
	static Logger log = Logger.getLogger("Logger Demo");

	public static void main(String[] args) throws Exception {

		Properties pro = new Properties();
		FileInputStream fis = new FileInputStream(
				"D:\\Users\\akakula\\Desktop\\javawork\\day1\\mypack\\log4j.properties");
		pro.load(fis);

		PropertyConfigurator.configure(pro);
		Logger Log = Logger.getLogger("LOGGER DEMO");

		log.trace("hello Tracr Message");
		log.debug("hello debug msg");
		log.info("hello info message");
		log.warn("hello warn message");
		log.error("hello error message");
		log.fatal("hello fatal message");
		System.out.println(">>>>>>>>>>>>>>end>>>>>>>>>>>>>>>>");

	}

}
