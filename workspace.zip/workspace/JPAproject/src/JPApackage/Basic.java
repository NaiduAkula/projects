package JPApackage;


	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.Persistence;
	 

	public class Basic {
	 
	    public static void main(String[] args) {
	        // TODO Auto-generated method stub
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
	        EntityManager em = emf.createEntityManager();
	        
	        Employee emp = new Employee();
	        
	        emp.setDesignation("Analyst");
	        emp.setEmpId(1234);
	        emp.setLocation("banagalore");
	        emp.setName("farooq");
	        
	        em.getTransaction().begin();
	        em.persist(emp);
	        em.getTransaction().commit();
	        System.out.println("record found");
	    }
	 
	}
	 

