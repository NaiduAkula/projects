package JDBCMain;

import java.util.List;

import com.myapp.dao.oracle.EmployeeOracleDAO;
import com.myapp.entity.Employee;
import com.myapp.service.EmployeeServiceImplementation;

public class EmployeeMain {

	public static void main(String[] args) throws Exception {
		EmployeeOracleDAO dao = new EmployeeOracleDAO();
		List<Employee> ans = dao.getAllEmployee();

		for (Employee employee : ans) {
			System.out.println(employee);
		}
		Employee empId = dao.getEmployeeByID(124);
		System.out.println(empId);

		System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		
		EmployeeServiceImplementation esi= new EmployeeServiceImplementation();
		Employee all=esi.getEmployeeDetails(184);
	System.out.println(all);

	
	//esi.AddEmployee();
		

		/*System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		List<Employee> dep = dao.getAllEmployeeByDepartment(50);
		for (Employee depn : dep) {
			System.out.println(depn);
		}

		System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		List<Employee> job = dao.getAllEmployeeByJobId("ST_CLERK");
		for (Employee jobid : job) {
			System.out.println(jobid);
		}
		System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		Employee empId = dao.getEmployeeByID(125);
		System.out.println(empId);

		System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		Employee email = dao.getEmployeeByEmail("JPATEL");
		System.out.println(email);

		System.out
				.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		System.out.println(email);

		Employee e = new Employee(545, "ghdghh", "dvbheghegh", "dbebjjh",
				"6778837347", "13-DEC-2014", "SH_CLERK", 3200.0, .32, 120, 50);

		//
		// for inserting use
		// dao.addEmployee(e);

		System.out.println("...............update......................");
		Employee e1 = new Employee();
		e1.setEmail("GHFFGHT");
		e1.setPhoneNumber("6778837883");
		e1.setSalary(4300.0);
		e1.setEmployeeId(140);

		dao.updateEmployee(e1);

		System.out.println("...............delete......................");

		e1.setDepartmentId(545);

		dao.deleteEmployee(e1);
		dao.deleteEmployee(196);

	}*/

}
}
