package com.myapp.dao;

import java.util.List;

import com.myapp.entity.Employee;

public interface EmployeeDAO {

	List<Employee> getAllEmployee() throws Exception;
	List<Employee> getAllEmployeeByDepartment(int departmentId) throws Exception;
	List<Employee> getAllEmployeeByJobId(String jobId) throws Exception ;
	Employee getEmployeeByID(int employeeId) throws Exception ;
	Employee getEmployeeByEmail(String email) throws Exception;
	void addEmployee(Employee e) throws Exception ;
	void updateEmployee(Employee e) throws Exception;
	void deleteEmployee(Employee e) throws Exception ;
	void deleteEmployee(int EmployeeId) throws Exception ;
	
}
