package com.myapp.dao;

import com.myapp.entity.Jobs;

public  interface JobsDAO {
	Jobs getJobTitles();
	Jobs getJobTitleByJobId(String jobId);
	Jobs getMinSalaryByJobTitle(String jobTitle);
	Jobs getMaxSalaryByJobTitle(String jobTitle);
	
	Jobs getMinSalaryByJobID(String jobId);
	Jobs getMaxSalaryByJobID(String jobId);
	Jobs getJobIdbyTitle(String jobTitle);
	 
	 void addJobs(Jobs j);
		void updateJobs(Jobs j);
		void deleteJobs(Jobs j);
		void deleteJobs(int jobId); 
}