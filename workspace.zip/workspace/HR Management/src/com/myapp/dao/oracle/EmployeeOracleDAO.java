package com.myapp.dao.oracle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.myapp.dao.EmployeeDAO;
import com.myapp.datasource.DataSorce;
import com.myapp.entity.Employee;

public class EmployeeOracleDAO implements EmployeeDAO {

	private static Connection getDBConnection(){
		Connection conn = null;
		FileInputStream fis = null;

		try {
			fis = new FileInputStream(
					"C:\\Users\\akakula\\workspace\\HR Management\\src\\db.properties");
			Properties dbpro = new Properties();
			dbpro.load(fis);
			String drivername = dbpro.getProperty("driver");

			String url = dbpro.getProperty("url");
			String user = dbpro.getProperty("user");
			String password = dbpro.getProperty("password");
			String maxConnection=dbpro.getProperty("maxConnection");
			Class.forName(drivername);
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException s) {
			s.printStackTrace();
		}catch(FileNotFoundException f){
			f.printStackTrace();
		}
		catch(IOException e){
			System.out.println("property file not loaded");
		}
		return conn;
	}

	@Override
	public List<Employee> getAllEmployee() throws Exception {

		ArrayList<Employee> empList = new ArrayList<Employee>();
		Connection conn =DataSorce.getConnection();
		Statement stmt = conn.createStatement();
		String q = "select  * from employees";
		ResultSet rs = stmt.executeQuery(q);

		Employee e = null;
		while (rs.next()) {
			e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getDouble(8), rs.getDouble(9),
					rs.getInt(10), rs.getInt(11));
			empList.add(e);
		}
		return empList;

	}

	@Override
	public List<Employee> getAllEmployeeByDepartment(int departmentId)
			throws Exception {

		ArrayList<Employee> depID = new ArrayList<Employee>();
		Connection conn =DataSorce.getConnection();
		Statement stmt = conn.createStatement();
		String q = "select  * from employees where department_Id=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setInt(1, departmentId);
		ResultSet rs = ps.executeQuery();
		Employee e = null;
		while (rs.next()) {
			e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getDouble(8), rs.getDouble(9),
					rs.getInt(10), rs.getInt(11));
			depID.add(e);
		}
		return depID;

	}

	@Override
	public List<Employee> getAllEmployeeByJobId(String jobId) throws Exception {

		ArrayList<Employee> jobID = new ArrayList<Employee>();
		Connection conn = DataSorce.getConnection();
		Statement stmt = conn.createStatement();
		String q = "select  * from employees where Job_Id=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setString(1, jobId);
		ResultSet rs = ps.executeQuery();
		Employee e = null;
		while (rs.next()) {
			e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getDouble(8), rs.getDouble(9),
					rs.getInt(10), rs.getInt(11));
			jobID.add(e);
		}
		return jobID;

	}

	@Override
	public Employee getEmployeeByID(int employeeId) throws Exception {
		// Employee emp;
		Connection conn =DataSorce.getConnection();
		Statement stmt = conn.createStatement();
		String q = "select  * from employees where Employee_Id=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setInt(1, employeeId);
		ResultSet rs = ps.executeQuery();
		Employee e = null;
		while (rs.next()) {
			e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getDouble(8), rs.getDouble(9),
					rs.getInt(10), rs.getInt(11));

			// add(e);
		}

		return e;
	}

	@Override
	public Employee getEmployeeByEmail(String email) throws Exception {
		Connection conn = DataSorce.getConnection();
		Statement stmt = conn.createStatement();
		String q = "select  * from employees where Email=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		Employee e = null;
		while (rs.next()) {
			e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getDouble(8), rs.getDouble(9),
					rs.getInt(10), rs.getInt(11));

			// add(e);
		}

		return e;
	}

	@Override
	public void addEmployee(Employee e) throws Exception {

		Connection conn =DataSorce.getConnection();

		// step3 create the statement object
		Statement stmt = conn.createStatement();

		// step4 execute query
		String q = " insert into employees values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setInt(1, e.getEmployeeId());
		ps.setString(2, e.getFirstName());
		ps.setString(3, e.getLastName());
		ps.setString(4, e.getEmail());
		ps.setString(5, e.getPhoneNumber());
		ps.setString(6, e.getHireDate());
		ps.setString(7, e.getJobId());
		ps.setDouble(8, e.getSalary());
		ps.setDouble(9, e.getCommissionPct());
		ps.setInt(10, e.getManagerId());

		ps.setInt(11, e.getDepartmentId());

		ps.executeUpdate();

	}

	@Override
	public void updateEmployee(Employee e1) throws Exception {

		Connection conn = DataSorce.getConnection();

		// step3 create the statement object
		Statement stmt = conn.createStatement();

		// step4 execute query
		String q = "update employees set Email=?,Phone_NUMber=?,salary=? where Employee_ID=?";
		PreparedStatement ps = conn.prepareStatement(q);

		ps.setString(1, e1.getEmail());
		ps.setString(2, e1.getPhoneNumber());

		ps.setDouble(3, e1.getSalary());

		ps.setInt(4, e1.getEmployeeId());

		int i;
		i = ps.executeUpdate();
		System.out.println(i);
	}

	@Override
	public void deleteEmployee(Employee e) throws Exception {
		Connection conn =DataSorce.getConnection();
		// step3 create the statement object
		Statement stmt = conn.createStatement();

		// step4 execute query
		String q = "delete from employees where Employee_ID=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setInt(1, e.getEmployeeId());
		int i;
		i = ps.executeUpdate();
		System.out.println(i);

	}

	@Override
	public void deleteEmployee(int EmployeeId) throws Exception{
		Connection conn =DataSorce.getConnection();
		Statement stmt = conn.createStatement();

		// step4 execute query
		String q = "delete from employees where Employee_ID=?";
		PreparedStatement ps = conn.prepareStatement(q);
		ps.setInt(1, EmployeeId);
		int i;
		i = ps.executeUpdate();
		System.out.println(i);

	}

}
