package com.myapp.datasource;

import java.sql.Connection;

public class DataSorce {

private static ConnectionPool pool;
static{
	try{
		String path= "C:\\Users\\akakula\\workspace\\HR Management\\src\\db.properties";
		pool= ConnectionPool.getConnectionPool(path);
	}catch(Exception e){
		
		
e.printStackTrace();	
		
		
		
	}
}
public static Connection getConnection()throws Exception{
	return pool.getConnection();
}



}
