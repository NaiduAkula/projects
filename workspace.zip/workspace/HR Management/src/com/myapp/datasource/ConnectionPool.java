package com.myapp.datasource;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;

public class ConnectionPool {

	private String userName;
	private String password;
	private String url;
	private int maxConnection;
	private int openConnection;

	private List<Connection> usedconnection = new ArrayList<Connection>();
	private Queue<Connection> freeconnection = new LinkedList<Connection>();
	private static ConnectionPool connectionPool;

	private ConnectionPool(String fileName) throws Exception {
		Properties properties = new Properties();
		FileInputStream fileIn = new FileInputStream(fileName);
		// Properties properties = new Properties();
		properties.load(fileIn);
		String driver = properties.getProperty("driver");
		url = properties.getProperty("url");
		userName = properties.getProperty("user");
		password = properties.getProperty("password");

		String max = properties.getProperty("maxConnection");
		maxConnection = Integer.parseInt(max);
		Class.forName(driver);
		fileIn.close();

	}

	private Connection openNewConnection() throws Exception {
		Connection conn=DriverManager.getConnection(url, userName, password);
		ManagedConnection connection = new ManagedConnection(this, conn);
	openConnection++;
	return connection;
	}

	public synchronized Connection getConnection() throws Exception {
		Connection conn = null;
		if (!freeconnection.isEmpty()) {
			conn = freeconnection.poll();

		} else {
			if (openConnection < maxConnection) {
				conn = openNewConnection();
			} else {
				throw new SQLException(
						"no more connection avaliable ,connection pool has reached maximum lines");
			}

		}
		usedconnection.add(conn);
		return conn;
	}

	public synchronized void returnConnection(Connection conn) {

		usedconnection.remove(conn);
		freeconnection.add(conn);
	}

	
		public static ConnectionPool getConnectionPool(String fileName)
					throws Exception {
				if (connectionPool == null) {
					connectionPool = new ConnectionPool(fileName);
					
				}
				return connectionPool; 
		}


	

}
