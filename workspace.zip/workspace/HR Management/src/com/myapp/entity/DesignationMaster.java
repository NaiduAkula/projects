package com.myapp.entity;

public class DesignationMaster {

	private int designCode;
	private String designName;
	public int getDesignCode() {
		return designCode;
	}
	public void setDesignCode(int designCode) {
		this.designCode = designCode;
	}
	public String getDesignName() {
		return designName;
	}
	public void setDesignName(String designName) {
		this.designName = designName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + designCode;
		result = prime * result
				+ ((designName == null) ? 0 : designName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DesignationMaster other = (DesignationMaster) obj;
		if (designCode != other.designCode)
			return false;
		if (designName == null) {
			if (other.designName != null)
				return false;
		} else if (!designName.equals(other.designName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DesignationMaster [designCode=" + designCode + ", designName="
				+ designName + "]";
	}
	public DesignationMaster(int designCode, String designName) {
		super();
		this.designCode = designCode;
		this.designName = designName;
	} 
	public DesignationMaster() {
		// TODO Auto-generated constructor stub
	}
}
