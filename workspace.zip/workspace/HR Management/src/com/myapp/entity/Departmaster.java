package com.myapp.entity;

public class Departmaster {

	
	private int deptCode;
	private String deptName;
	public int getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(int deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + deptCode;
		result = prime * result
				+ ((deptName == null) ? 0 : deptName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Departmaster other = (Departmaster) obj;
		if (deptCode != other.deptCode)
			return false;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Departmaster [deptCode=" + deptCode + ", deptName=" + deptName
				+ "]";
	}
	public Departmaster(int deptCode, String deptName) {
		super();
		this.deptCode = deptCode;
		this.deptName = deptName;
	}
public Departmaster() {
	// TODO Auto-generated constructor stub
}

	
}
