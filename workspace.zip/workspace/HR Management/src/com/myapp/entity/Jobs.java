package com.myapp.entity;

public class Jobs {
	private String jobId;
	private String jobTitle;
	private int minSalary;
	private int maxSalary; 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
