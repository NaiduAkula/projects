package com.myapp.entity;

public class Locations {

	
	private int locationId;
	private String streetAddress;
	private String postalCode;
	private String city;
	private String stateProvince;
	private String countryId;
	
	
	
	
	
}
