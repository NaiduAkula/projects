package com.myapp.ui;

import java.util.Scanner;

import com.myapp.entity.Employee;
import com.myapp.service.EmployeeServiceImplementation;

public class MyAppUI {
	 static int choice;
	 static EmployeeServiceImplementation esi= new EmployeeServiceImplementation();
	public static void main(String[] args) throws Exception {
	Scanner sc= new Scanner(System.in);
	 
	System.out.println("enter the choices");
	System.out.println("choice 1:to get employee details");	
	System.out.println("choice 2:to add employee details");	
	System.out.println("choice 3:to update employee details");	
	System.out.println("choice 4:to delete employee details");	
	System.out.println("choice 5:exit");	
	choice= sc.nextInt();
	switch (choice) {
	case 1:
		System.out.println("enter the employeeId");
		 int i=sc.nextInt();
		
		Employee all=esi.getEmployeeDetails(i);
		System.out.println(all);
		break;
		
	case 2:
		System.out.println("enter details");
		int employeeid=sc.nextInt();
		Scanner sc1= new Scanner(System.in);
		String firstname=sc.nextLine();
		String lname=sc.nextLine();
		String email=sc.nextLine();
		String pno= sc.nextLine();
		String hid=sc.nextLine();
		String jid=sc.nextLine();
		double sal=sc.nextDouble();
		double com=sc.nextDouble();
		int mid=sc.nextInt();
		int did=sc.nextInt();
		
		Employee e = new Employee(employeeid,firstname,lname,email,pno,hid,jid,sal,com,mid,did);
		esi.AddEmployee(e);

		
		break;
		
	default:
		break;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
