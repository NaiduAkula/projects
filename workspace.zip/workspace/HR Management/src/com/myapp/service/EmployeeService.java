package com.myapp.service;

import com.myapp.entity.Employee;

public interface EmployeeService {

	Employee getEmployeeAllDetails(int employeeId) throws Exception;
	Employee getEmployeeDetails(int employeeId) throws Exception;
	void AddEmployee(Employee e) throws Exception;
	void UpdateEmployee(Employee e) throws Exception;
	
	void DeleteEmployee(Employee e) throws Exception;
	
	
	
	
	
	
	
	
	
}
