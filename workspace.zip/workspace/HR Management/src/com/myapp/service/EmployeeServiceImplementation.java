package com.myapp.service;

import com.myapp.dao.EmployeeDAO;
import com.myapp.dao.oracle.EmployeeOracleDAO;
import com.myapp.entity.Employee;

public class EmployeeServiceImplementation  implements EmployeeService{

EmployeeDAO empDAO;	
	
public EmployeeServiceImplementation() {
	
	empDAO= new EmployeeOracleDAO();
}

@Override
public Employee getEmployeeAllDetails(int employeeId) throws Exception {
	// TODO Auto-generated method stub
	return null;
}

@Override
public Employee getEmployeeDetails(int employeeId) throws Exception {
	return empDAO.getEmployeeByID(employeeId);
}

@Override
public void AddEmployee(Employee e) throws Exception {
	empDAO.addEmployee(e);
}

@Override
public void UpdateEmployee(Employee e) throws Exception {
	empDAO.updateEmployee(e);
}

@Override
public void DeleteEmployee(Employee e) throws Exception {
	empDAO.deleteEmployee(e);
}

}

