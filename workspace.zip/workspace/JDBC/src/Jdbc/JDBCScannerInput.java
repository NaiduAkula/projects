package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCScannerInput {

	public static void main(String[] args) throws Exception {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";
		
		Scanner sc = new Scanner(System.in);
		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);
		String q = "update emp set sal=?,comm=? where empno=?";
		PreparedStatement ps = con.prepareStatement(q);
		System.out.println("enter the sal");

		ps.setDouble(1, sc.nextDouble());

		System.out.println("enter the commission");
		ps.setDouble(2, sc.nextDouble());
		System.out.println("enter the empno");
		ps.setDouble(3, sc.nextInt());
		ps.executeUpdate();
		System.out.println("updated succesfully");

	}

}
