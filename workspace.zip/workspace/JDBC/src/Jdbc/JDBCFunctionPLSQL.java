package Jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class JDBCFunctionPLSQL {

	public static void main(String[] args) throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";

		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);

		// step3 create the statement object
		Statement stmt = con.createStatement();

		// step4 execute query
		/*
		 * String q = "create or replace function deptNo(p1 in number) return
		 * number IS SUMSAL NUMBER(10,2); BEGIN SELECT SUM(SAL) INTO SUMSAL FROM
		 * EMP WHERE DEPTNO=P1; RETURN SUMSAL; +"IS" +"SUMSAL NUMBER(10,2);"
		 * +"BEGIN" +" SELECT SUM(SAL) INTO SUMSAL FROM EMP  WHERE DEPTNO=P1;"
		 * +" RETURN  SUMSAL;" +"  END;" +" /";
		 * 
		 * //stmt.executeUpdate(q); PreparedStatement ps=
		 * con.prepareStatement(q); ps.executeUpdate();
		 * 
		 * 
		 * 
		 * /* CallableStatement cs= con.prepareCall("{?=call deptNo(?)}");
		 * cs.setInt(2,10); cs.registerOutParameter(1,Types.INTEGER);
		 * cs.execute(); System.out.println(cs.getInt(1));
		 */

		CallableStatement cs = con.prepareCall("{?=call deptNo(?)}");
		cs.setInt(2, 10);
		cs.registerOutParameter(1, Types.INTEGER);
		cs.execute();
		System.out.println(cs.getInt(1));

		System.out.println("data updated ");
	}

}
