package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCInsert {

	public static void main(String[] args) throws Exception {
		// step1 load the driver class

		Class.forName("oracle.jdbc.OracleDriver");

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";

		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);

		// step3 create the statement object
		Statement stmt = con.createStatement();

		// step4 execute query
		String q = " insert into emp(empno,ename,hiredate) values(7678,'aditya','13-apr-97')";
		stmt.executeUpdate(q);
		
		System.out.println("data inserted ");
	}

}
