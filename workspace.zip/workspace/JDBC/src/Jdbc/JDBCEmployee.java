package Jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCEmployee {

	public static void main(String[] args) throws Exception {
	
		// step1 load the driver class

				Class.forName("oracle.jdbc.OracleDriver");

				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user = "hr";
				String password = "hr";

				// step2 create the connection object
				Connection con = DriverManager.getConnection(url, user, password);

				// step3 create the statement object
				Statement stmt = con.createStatement();

				// step4 execute query
				String q = "select * FROM EMP";
				ResultSet rs = stmt.executeQuery(q);

				int id = 0;
				String name = "";
				String job="";
				int mgr=0;
				double sal;
				double comm;
				int deptno=0;
				Date date;

			while (rs.next()) {

					id = rs.getInt("EMPNO");
					name = rs.getString("ENAME");
					job=  rs.getString("JOB");
					mgr= rs.getInt("MGR");
					sal= rs.getDouble("SAL");
					comm= rs.getDouble("COMM");
					deptno= rs.getInt("DEPTNO");
					date=rs.getDate("HIREDATE");
					System.out.println(id + "     " + name+"      "+job+"     "+mgr+"    "+sal+"    "+comm+"    "+deptno+"     "+date);

				}
			rs.close();
			stmt.close();
			con.close();

				System.out.println("connected to oracle db...........");

			}

		}

	