package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JDBCUpdate {

	public static void main(String[] args) throws Exception {

		Class.forName("oracle.jdbc.OracleDriver");

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";

		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);

		// step3 create the statement object
		Statement stmt = con.createStatement();

		// step4 execute query
		String q = "update emp set job='analyst',mgr=6945,sal=1856,comm=98,deptno=10 where empno=7678";
		stmt.executeUpdate(q);
		
		System.out.println("data updated ");
	}

}
