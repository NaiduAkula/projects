package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCPrepared {

	public static void main(String[] args) throws Exception {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";

		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);
		String q="update emp set sal=?,comm=? where empno=?";
		PreparedStatement ps= con.prepareStatement(q);
		ps.setDouble(1, 10000.0);
		ps.setDouble(2, 900.0);
		ps.setDouble(3, 7678);
		ps.executeUpdate();
		System.out.println("updated succesfully");
		

	}

}
 