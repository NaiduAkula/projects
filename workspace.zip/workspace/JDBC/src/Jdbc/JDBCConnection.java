package Jdbc;

import java.sql.*;

public class JDBCConnection {

	public static void main(String[] args) throws Exception {
		// step1 load the driver class

		Class.forName("oracle.jdbc.OracleDriver");

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";

		// step2 create the connection object
		Connection con = DriverManager.getConnection(url, user, password);

		// step3 create the statement object
		Statement stmt = con.createStatement();

		// step4 execute query
		String q = "select EMPNO,ENAME FROM EMP";
		ResultSet rs = stmt.executeQuery(q);

		int id = 0;
		String name = "";

	while (rs.next()) {

			id = rs.getInt("EMPNO");
			name = rs.getString("ENAME");
			System.out.println(id + " " + name);

		}

		System.out.println("connected to oracle db...........");

	}

}
