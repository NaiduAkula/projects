package com.capgemini.doctors.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = "insert into doctor-appointment(appointment_id,patient_name,phone_number,email,age,gender,problem_name,doctor_name,appointment_status) values(seq_appointment_id.nextval,?,?,?,?,?,?,?,?))";
	static String SEARCH_DOCTOR = "select doctor_name from problems where problem_name=?";
	static String GET_APPOINTMENT_DETAILS = "select patient_name,appointment_status,doctor_name,date_of_appointemnt from doctor_appointment where appointment_id=?";
	static String GET_PROBLEM_NAMES ="SELECT problem_name FROM problems ";
}
