package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorsException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {
	private static Scanner in;

	private static IDoctorAppointmentService ida = new DoctorAppointmentService();
	
	






	public static void main(String[] args) throws DoctorsException {


		in = new Scanner(System.in);
		System.out.println(" \nWelcome to doctor appointment service\n");
		while (true) {
			System.out.println(" \nEnter your choice:\n");
			System.out.println(" 1.Book Doctor Appointement\n");
			System.out.println(" 2.View Doctor Appointement\n");
			System.out.println(" 3.Exit\n");
			int choice = in.nextInt();
			switch (choice) {

			case 1:
				getInputs();
				break;

			case 2:
				getDetails();
				break;

			case 3:
				System.out.println("\n\nThank you");
				System.exit(0);

			}

		}

	}
	
	
	
private static void getInputs() throws DoctorsException {
		
		String patientName;
		String PhoneNumber;
		String email;
		int age;
		String gender;
		String problemName;
		String status;
		String doctorName = null;
		
		DoctorAppointment da = new DoctorAppointment();

		

			while (true) {
				in.nextLine();
				System.out.println("Enter patient name");

				patientName = in.nextLine();

				if (ida.validatePatientName(patientName)) {
					break;
				} else {
					System.out.println("Invalid patient name");
				}
			}

			while (true) {
				System.out.println("Enter phone number");

				PhoneNumber = in.next();

				if (ida.validatePhoneNumber(PhoneNumber)) {
					break;
				} else {
					System.out.println("Invalid phone number");
				}
			}

			while (true) {
				System.out.println("Please enter mail id ");

				email = in.next();

				if (ida.validateMailId(email)) {
					break;
				} else {
					System.out.println("Invalid mail id");
				}
			}

			while (true) {
				System.out.println("Please enter age ");

				age = in.nextInt();
				String Age = Integer.toString(age);

				if (ida.validateAge(Age)) {
					break;
				} else {
					System.out.println("Invalid age");
				}
			}

			while (true) {
				System.out.println("Please enter gender");

				gender = in.next();

				if (ida.validateGender(gender)) {
					break;
				} else {
					System.out.println("Invalid gender");
				}
			}
			
				System.out.println("Enter Problem name");
				problemName = in.next();
				if (ida.getProblemNames().contains(problemName.toUpperCase())) {
					status = "Approved";
					
				} else {
					status = "DisApproved";
					
				}
			DoctorAppointmentDao dao=new DoctorAppointmentDao();
			List<String> doctor = dao.getDoctorName(problemName.toUpperCase());
			/*StringBuilder sb = new StringBuilder();

			for (Object obj :doctor) {
			  sb.append(obj.toString());
			  sb.append("\t");
			}
*/
			// doctorName = sb.toString();
			
			for (String string : doctor) {
				doctorName=string;
			}
			
			
		//	System.out.println(doctorName);
			
			
			
				
				da.setPatientName(patientName);
				da.setPhoneNumber(PhoneNumber);
				da.setEmail(email);
				da.setAge(age);
				da.setGender(gender);
				da.setProblemName(problemName);
				da.setDoctorName(doctorName);
				da.setAppointmentStatus(status);
				
				ida.addDoctorAppointmentDetails(da);
			
	}


private static void getDetails() throws DoctorsException {
	System.out.println("enter appointmentId");
	int appointmentId=in.nextInt();

	
DoctorAppointment detailsforappointment =ida.getAppointmentDetails(appointmentId);
	
	System.out.println(detailsforappointment);
	
	
	
	
}

}
