package rolling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;





public class ClassRolling {
	static Logger log = Logger.getLogger(ClassRolling.class.getName());
	Object x;
	public void method(int a,float b){
		log.info("do something are: "+a+""+b);
		log.debug("operation perfiormes succesfully");
		if(x==null){
			log.error("value of x is null");
			
		}
	}
public static void main(String[] args) throws Exception {
	Properties pro = new Properties();
	FileInputStream fis = new FileInputStream(
			"D:\\Users\\akakula\\Desktop\\javawork\\day1\\mypack\\log4j1.properties");
	pro.load(fis);

	PropertyConfigurator.configure(pro);
	//PropertyConfigurator.configure("");
	ClassRolling r= new ClassRolling();
	r.method(10, 3);
	
	
	
}
}
