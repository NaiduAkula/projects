package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import LabBookSprings.EmployeeSprings;

public class SBUmain {

	public static void main(String[] args) {

		Resource resource= new ClassPathResource("sbu.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resource);
		Employeesbu employeesbu=(Employeesbu)beanFactory.getBean("Employee");
		employeesbu.displayemp();
		
		
		
	}

}
