package com.cg.injdep;

import java.util.List;

public class Collect {
	List<EmployeeDep> empdetails;

	public List<EmployeeDep> getEmpdetails() {
		return empdetails;
	}

	public void setEmpdetails(List<EmployeeDep> empdetails) {
		this.empdetails = empdetails;
	}

	public Collect(List<EmployeeDep> empdetails) {
		super();
		this.empdetails = empdetails;
	}

	
public Collect() {
	// TODO Auto-generated constructor stub
}
}
