package com.cg.injdep;

public class EmpService {




private static EmpDAO employeedep001;


public EmpDAO getEmployeedep001() {
	return employeedep001;
}
public void setEmployeedep001(EmpDAO employeedep001) {
	this.employeedep001 = employeedep001;
}

	public static EmployeeDep getEmpDetails(int employeeId) {
		return employeedep001.getEmpDetails(employeeId);
	}

}
