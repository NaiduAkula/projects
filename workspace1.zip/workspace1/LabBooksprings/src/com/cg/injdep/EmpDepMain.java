package com.cg.injdep;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;



public class EmpDepMain {

	public static void main(String[] args) {
		Resource resource= new ClassPathResource("cons.xml");
		BeanFactory beanFactory= new XmlBeanFactory(resource);
		Object obj = beanFactory.getBean("employeedep");
		EmpService empService=(EmpService) obj;
		

Scanner sc= new Scanner(System.in);
EmployeeDep list=empService.getEmpDetails(sc.nextInt());

System.out.println(list);

		
	}

}
