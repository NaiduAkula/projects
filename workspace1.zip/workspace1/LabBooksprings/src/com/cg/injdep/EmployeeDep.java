package com.cg.injdep;

public class EmployeeDep {
	
		int employeeId;

		String employeename;
		double employeeSalary;
		
		public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeename() {
			return employeename;
		}
		public void setEmployeename(String employeename) {
			this.employeename = employeename;
		}
		@Override
		public String toString() {
			return "EmployeeDep [employeeId=" + employeeId + ", employeename="
					+ employeename + ", employeeSalary=" + employeeSalary + "]";
		}
		public double getEmployeeSalary() {
			return employeeSalary;
		}
		public void setEmployeeSalary(double employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
		public EmployeeDep(int employeeId, String employeename,
				double employeeSalary) {
			super();
			this.employeeId = employeeId;
			this.employeename = employeename;
			this.employeeSalary = employeeSalary;
		}
	public EmployeeDep() {
		// TODO Auto-generated constructor stub
	}
	

}
