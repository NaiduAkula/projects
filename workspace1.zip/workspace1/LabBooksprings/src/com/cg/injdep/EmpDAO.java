package com.cg.injdep;

import java.util.Iterator;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.cglib.proxy.Factory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.list.ListSBU;

public class EmpDAO {
	
	/*private EmployeeDep employeeDep;
	

	public EmployeeDep getEmployeeDep() {
		return employeeDep;
	}


	public void setEmployeeDep(EmployeeDep employeeDep) {
		this.employeeDep = employeeDep;
	}
*/

	//EmployeeDep employeeDep= new EmployeeDep();
	public EmployeeDep getEmpDetails(int employeeId) {
		EmployeeDep employeeDep= new EmployeeDep();
		Resource resource= new ClassPathResource("cons.xml");
		BeanFactory beanFactory= new XmlBeanFactory(resource);
	Collect collect=(Collect)beanFactory.getBean("collist");
	Iterator<EmployeeDep> iterator=collect.empdetails.iterator();
	
	while(iterator.hasNext()){
		 employeeDep=iterator.next();
		if(employeeDep.getEmployeeId()==employeeId)
			return employeeDep;
		
		//return employeeDep;
	}
	return employeeDep;

	}

}
