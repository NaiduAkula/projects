package com.cg.list;

import java.util.Iterator;
import java.util.List;


public class ListSBU {
	
	int sbuId;
	String sbuName;
	String sbuHead;
	List<EmployeeList> emplist;
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<EmployeeList> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<EmployeeList> emplist) {
		this.emplist = emplist;
	} 
	
	public void displayemp() {
		System.out.println("....employeedetails....");
		System.out.println(" getSbuId():" + getSbuId());
		System.out.println("getSbuHead() :" +getSbuHead());
		System.out.println("getSbuName() :" + getSbuName());
		Iterator<EmployeeList> list= emplist.iterator();
		while(list.hasNext()){
			System.out.println(list.next());
		}
		
		
		
		

	}
	

}
