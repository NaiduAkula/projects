package com.cg.list;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ListMain {

	public static void main(String[] args) {		
		Resource resource= new ClassPathResource("list.xml");
		BeanFactory beanFactory= new XmlBeanFactory(resource);
		ListSBU listSBU=(ListSBU)beanFactory.getBean("sbulist");
listSBU.displayemp();
	}

}
