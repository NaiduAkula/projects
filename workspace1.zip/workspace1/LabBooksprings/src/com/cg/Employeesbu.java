package com.cg;

public class Employeesbu{
	
	
	int employeeId;
	
	String employeename;
	double employeeSalary;
	SBU businessUnit;
	
	


	public int getEmployeeId() {
		return employeeId;
	}




	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}




	public String getEmployeename() {
		return employeename;
	}




	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}




	public double getEmployeeSalary() {
		return employeeSalary;
	}




	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}




	public SBU getBusinessUnit() {
		return businessUnit;
	}




	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}




	public void displayemp() {
		System.out.println("....enployeedetails....");
		System.out.println(" getEmployeeId():"+ getEmployeeId());
		System.out.println(" getEmployeename() :"+ getEmployeename() );
		System.out.println("getEmployeeSalary() :"+getEmployeeSalary() );
	System.out.println(businessUnit);
	
		
	}

	
	

}
