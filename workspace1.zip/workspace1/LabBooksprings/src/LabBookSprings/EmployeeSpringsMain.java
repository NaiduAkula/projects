package LabBookSprings;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class EmployeeSpringsMain {

	public static void main(String[] args) {

		
		Resource resource= new ClassPathResource("employee.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resource);
		EmployeeSprings employeeSprings=(EmployeeSprings)beanFactory.getBean("EmployeeDetails");
		employeeSprings.displayemp();
		
		
	}

}
