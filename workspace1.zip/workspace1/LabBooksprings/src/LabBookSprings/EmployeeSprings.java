package LabBookSprings;

public class EmployeeSprings {
	
	
	int employeeId;
	
	String employeename;
	double employeeSalary;
	String businessUnit;
	int employeeAge;
	
	
	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeename() {
		return employeename;
	}


	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}


	public double getEmployeeSalary() {
		return employeeSalary;
	}


	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}


	public String getBusinessUnit() {
		return businessUnit;
	}


	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}


	public int getEmployeeAge() {
		return employeeAge;
	}


	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}


	public void displayemp() {
		System.out.println("....enployeedetails....");
		System.out.println(" getEmployeeId():"+ getEmployeeId());
		System.out.println(" getEmployeename() :"+ getEmployeename() );
		System.out.println("getEmployeeSalary() :"+getEmployeeSalary() );
		System.out.println(" getBusinessUnit(): "+ getBusinessUnit());
		System.out.println("getEmployeeAge(): "+getEmployeeAge());
		
		
		
	}
	

}
