package SpringPack;

public class WelcomeService  implements GreetingService{

	@Override
	public String sayGreeting() {
		// TODO Auto-generated method stub
		return "Welcome";
	}

	public WelcomeService() {
		super();
		
		System.out.println("fffffffffffffftttttttttttttttttpppppppppppp");
	}

}
