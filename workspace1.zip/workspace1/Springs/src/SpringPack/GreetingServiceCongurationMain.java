package SpringPack;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class GreetingServiceCongurationMain {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext annotationConfigApplicationContext=new AnnotationConfigApplicationContext();
		annotationConfigApplicationContext.register(GreetingServiceConfiguration.class);
		annotationConfigApplicationContext.refresh();
	GreetingService greetingService=(GreetingService)annotationConfigApplicationContext.getBean("welcome");
		String m= greetingService.sayGreeting();
		System.out.println(m);
		//annotationConfigApplicationContext.close();
		
		
		List<String> list	=(List<String>)annotationConfigApplicationContext.getBean("getValues");
		for (String string : list) {
			System.out.println(string);
			
		}
		annotationConfigApplicationContext.close();
	}

}
