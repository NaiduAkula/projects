package SpringPack;

public class HelloService  implements GreetingService{

	@Override
	public String sayGreeting() {
		
		
		return "Hello";
	}

}
