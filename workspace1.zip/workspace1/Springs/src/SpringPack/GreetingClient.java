package SpringPack;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.*;
import org.springframework.core.io.*;

public class GreetingClient {


		public static void main(String args[]) throws Exception {
	Resource res = new ClassPathResource
				("config.xml");
			
			BeanFactory factory = new XmlBeanFactory(res);
			
		
			
			
				Object greeting	=factory.getBean("Greeting");
			GreetingService greetingseService = (GreetingService)greeting;
			
	String message= greetingseService.sayGreeting();
	System.out.println(message);
	
	Object greeting1	=factory.getBean("Greeting1");
	GreetingService greetingseService1 = (GreetingService)greeting1;
	String message1= greetingseService1.sayGreeting();
	System.out.println(message1);
	
	
	
		}
	}


