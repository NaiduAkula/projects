package SpringPack;



public interface GreetingService {
	
       String sayGreeting();
}
