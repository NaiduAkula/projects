package SpringPack;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GreetingServiceConfiguration {
	@Bean
	public GreetingService hello(){
		return   new HelloService();
	}
	@Bean
	public GreetingService welcome(){
		return   new WelcomeService();
	}
	@Bean
	public List<String> getValues(){
		List<String > cities= new ArrayList<String>();

		cities.add("HYD");
		cities.add("MUM");
		cities.add("BAN");
		cities.add("Che");
		return cities;
		
	}
	
}
