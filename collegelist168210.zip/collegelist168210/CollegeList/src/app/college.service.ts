import { Injectable } from '@angular/core';
import college from './college.json';

@Injectable({
  providedIn: 'root'
})
export class CollegeService {
  allColleges:any;
  constructor() { 
    this.allColleges=college;
  }

  showAllColleges(){
    this.allColleges.forEach(element => {
      console.log(element.collegeId)
    });
    return this.allColleges;
  }

  deleteCollege(collegeno:number){
    for(var i=0;i < this.allColleges.length;i++){
      if(this.allColleges[i].collegeId==collegeno){
      this.allColleges.splice(i,1);
      return this.allColleges;
      }
    } 
  }

  sortbyCollegeID(){
    this.allColleges=this.allColleges.sort((a,b)=>(a.collegeId-b.collegeId));
  }

  sortbyCollegeName(){
    this.allColleges=this.allColleges.sort((a,b)=>(a.collegeName>b.collegeName ?1:-1));
  }

  sortbyCollegeState(){
    this.allColleges=this.allColleges.sort((a,b)=>(a.state>b.state ?1:-1));
  }
 
}