import {  Component,OnInit } from '@angular/core';
import { CollegeService } from '../college.service';

@Component({
  selector: 'app-colleges',
  templateUrl: './colleges.component.html',
  styleUrls: ['./colleges.component.css']
})
export class CollegesComponent implements OnInit {
  collegesList:any;
  constructor(private collegeService:CollegeService) { }
  getAllColleges(){
    this.collegesList=this.collegeService.showAllColleges();
  }
  deleteData(collegeno:number){
    console.log(collegeno);
    this.collegesList=this.collegeService.deleteCollege(collegeno);
    
  }

  sortById(){
    this.collegeService.sortbyCollegeID();
  }
  ngOnInit() {
  }

  sortByName(){
    this.collegeService.sortbyCollegeName();
  }

  sortByState(){
    this.collegeService.sortbyCollegeState();
  }

}
